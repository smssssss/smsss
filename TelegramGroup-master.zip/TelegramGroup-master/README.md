<!--
 * @Description:
 * @telegram: @tghzsx_bot
-->
## 声明
<div align="center">
【电报推荐】10000+ 优质Telegram群组、Telegram频道推荐、频道和机器人，精心筛选，让您轻松玩转Telegram。

❗️❗️❗️本文内容严禁在中国大陆使用，一切违法后果请自行承担❗️❗️❗️

❗️❗️❗️所有频道群组采集自网络，真实性未知,侵权请联系删除❗️❗❗️️

❗️❗️❗️存在️广告内容，请自行辨别真假管好自己的钱包，出问题本站概不负责❗️❗️❗️


<img src="https://i.imgur.com/ywjcaE6.png" alt="USDT">
电报中文昵称也就是汉字❗️请点击以下机器人免费领取USDT❗️<img src="https://cryptologos.cc/logos/tether-usdt-logo.png" alt="USDT" width="12" height="12">
(泰达币Tether),数量有限先到先得

商务合作：[@tghzsx_bot](https://t.me/tghzsx_bot)

</div>

<!-- BEGIN_REPLACE_SECTION -->
| [![@TG最强搜索机器人](https://i.imgur.com/uTMZCDf.png)<br>@TG最强搜索机器人](https://t.me/sosoo?start=a_7737195905) | [![@同城约炮](https://i.imgur.com/hFz9t0f.png)<br>玩偶姐姐](https://t.me/+boSRNynHORVjMmNh)    | [![@极搜JiSo](https://i.imgur.com/we9lyse.jpeg)<br>@极搜JiSo](https://t.me/jiso?start=a_7202424896) |
|:---:|:---:|:---:|
|[![@极搜JiSou](https://i.imgur.com/1VoAGvh.png)<br>@极搜JiSou](https://t.me/jisou2bot?start=a_7737195905) |  [![Telegram频道导航/TG导航/Telegram频道推荐/Telegram导航/频道导航/电报导航/电报推荐/TG推荐](https://i.imgur.com/31YFV0f.png)<br>Telegram频道导航](https://tgdh.github.io) |[![@i快搜](https://i.imgur.com/CsCtOBH.png)<br>@i快搜](https://t.me/ikuaisobot?start=7352210715)|
| [![搜片神器](https://i.imgur.com/SVox0Se.png)<br>搜片神器](https://t.me/soupianshenqibar)  |  [![色色搜索](https://i.imgur.com/pwNAjvK.png)<br>❤️色色搜索🔞](https://t.me/sesouccav) | [![暗网搜索](https://i.imgur.com/woGNZUA.png)<br>暗网搜索](https://t.me/anwangbots)|
| [![彩虹群发破解版/飞机/电报Telegram tdata/低价TG账号/电报资源搜索](https://i.imgur.com/xff6d05.png)<br>电报稀缺资源大全中文搜索](https://t.me/sousuohp)|  [![彩虹群发器/彩虹群发/彩虹群发器破解版](https://i.imgur.com/6a8Zz9h.png)<br>彩虹群发器破解版](https://t.me/autocaihongbot?start=gwHypTpEnF84wUi)  |[![机场导航](https://i.imgur.com/yhw5VPW.png)<br>机场导航大全](https://jichangvpn.github.io/)|
<!-- END_REPLACE_SECTION -->
</table>

| **导航名称**       | **链接**                                           |
|-----------------|---------------------------------------------------|
| **🛫机场VPN导航站🛫** | [https://jichangvpn.github.io](https://jichangvpn.github.io) |
| **🎯Telegram频道群组导航站🎯** | [https://tgdh.github.io](https://tgdh.github.io)或[https://www.tg10000.com](https://www.tg10000.com) |
| **🎯AI导航站🎯** | [https://ai-navs.github.io](https://ai-navs.github.io) |
| **🌈彩虹群发器🌈**         | [https://t.me/autocaihongbot](https://t.me/autocaihongbot?start=gwHypTpEnF84wUi)(机器人自助购买) |
| **🔥全国找妹子🔥**  | [https://t.me/+bJkN6Cz7WIQ5YjQ9](https://t.me/+bJkN6Cz7WIQ5YjQ9) |
| **🔥全国找妹纸🔥**  | [https://t.me/+yjr6MItkuRJkMDFl](https://t.me/+yjr6MItkuRJkMDFl) |

### 推荐

| 频道名称             | 链接                                       | 描述                        |
|--------------------|--------------------------------------------|---------------------------------|
| 🔥 频道导航/群组导航 | [https://t.me/tgpddh](https://t.me/tgpddh)   | Telegram频道和群组导航合集      |
| 🚀 每日免费节点       | [https://t.me/freevpntg](https://t.me/freevpntg) | 每日免费提供高速的VPN节点         |
| 🔥 电报中文包       | [https://t.me/go2cn](https://t.me/go2cn) | 电报使用人数最多的中文包         |
| 🔥 修女频道搬运        | [https://t.me/xiunvbanyun](https://t.me/xiunvbanyun) |   [@freexnby_bot](https://t.me/freexnby_bot)破解自动搬运别人频道到自己频道   |
| 🔥 TG全能搜索        | [https://t.me/sesou20w](https://t.me/sesou20w) | 支持多种资源的强大搜索引擎      |
| 🎥 电影搜索Pron      | [https://t.me/sepiansousuo](https://t.me/sepiansousuo) | 支持电影、资源的搜索功能      |
| 🔥 极搜20万人搜索群   | [https://t.me/jisou200000](https://t.me/jisou200000) | 热门搜索群，涵盖多种资源       |
| 🔥 资源搜索          | [https://t.me/resource4](https://t.me/resource4) | 提供多类型的资源搜索功能      |
| 🔥 稀缺资源搜索      | [https://t.me/sosobo2](https://t.me/sosobo2) | 提供稀缺资源的专门搜索        |
| 🔥 神马搜索         | [https://t.me/smss](https://t.me/smss?start=spread_7202424896)       | 提供快速资源搜索服务          |
| 🔥 aiso中文搜索     | [https://t.me/aiso](https://t.me/aiso?start=telegram_7202424896)       | 中文资源搜索引擎             |
| 🔥 哆啦A梦软件App| [https://t.me/dlamapp](https://t.me/dlamapp) | 各种软件、App和VPN破解资源    |
| 🔥 NSFW| [https://github.com/telegrampron/telegram-nsfw](https://github.com/telegrampron/telegram-nsfw) | 电报极品频道，懂的都懂    |
| 🔥 色瓜中心| [https://t.me/seguazhongxin](https://t.me/seguazhongxin) | 分享全网第一热瓜|
| 🔥 全网直播回放      | [https://t.me/luzhiob](https://t.me/luzhiob)   | 直播回放资源，涵盖抖音、斗鱼等  |
| 🎥 阿里云盘4K高清资源  | [https://t.me/alidriver4k](https://t.me/alidriver4k) | 阿里云盘的4K高清资源分享      |
| 🔥 国内大流量卡       | [https://t.me/LiuLiangKa_2024](https://t.me/LiuLiangKa_2024) | 29元200G大流量卡信息         |
| 🔥 奈飞小铺         | [https://ihezu.fans](https://ihezu.fans)     | 提供Spotify、网飞等平台的拼车服务 |
| 🔥 环球巴士         | [https://universalbus.cn](https://universalbus.cn) | 全球一站式合租平台，支持多平台  |
| 🔥 账号星球         | [https://www.accountboy.com](https://www.accountboy.com/?source=tggroup) | 苹果全球id，GPT/奈飞合租，海外社媒账号/邮箱  |
| 🔞 推特女菩萨      | [https://t.me/+RSwm4w2RoUA4N2Nl](https://t.me/+RSwm4w2RoUA4N2Nl)  |  骗子    |
| 🔞 女神聚集地       | [https://t.me/+59_7EXqZ5n41MDQ1](https://t.me/+59_7EXqZ5n41MDQ1) |    骗子  |
| 🔞 不良少女         | [https://t.me/+SUetv8Cm-wEzM2Zl](https://t.me/+SUetv8Cm-wEzM2Zl) |      骗子|
| 🔞 女大学生         | [https://t.me/+bP2C6wrFOjxkMTVk](https://t.me/+bP2C6wrFOjxkMTVk) |      骗子|

### 搜索群大全

|搜   | 索   | 群   |
|-------|-------|-------|
| [电报搜索群①](https://t.me/daohangsese) | [电报搜索群②](https://t.me/soupianshenqi1314) | [电报搜索群③](https://t.me/soupianshenqi520) |
| [电报搜索群④](https://t.me/chengrendaohang520) | [电报搜索群⑤](https://t.me/sesou20w) | [电报搜索群⑥](https://t.me/resource4) |
| [电报搜索群⑦](https://t.me/sosobo2) | [电报搜索群⑧](https://t.me/sousuo20w) | [电报搜索群⑨](https://t.me/qnssking) |

### 机器人搭建有需要联系:[@banyunpindao](https://t.me/banyunpindao)
| 项目                                       | 说明                                              | 价格            |
| ------------------------------------------ | ------------------------------------------------- | --------------- |
| 自动上传脚本                                | 提供源码及搭建服务，效果查看：[@dysyg](https://t.me/dysyg)          | 50U             |
| 修女频道搬运                                | 搬运整个频道10U,自行联系[@banyunpindao](https://t.me/banyunpindao) | 10U   |
| 自动转发频道机器人(涨粉神器)                          | 自动监听搬运别人频道内容,提供源码及搭建服务[@banyunpindao](https://t.me/banyunpindao) | 100U            |
| 自动转发频道机器人（文末广告+关键字替换+过滤）       | 自动搬运别人频道内容并可自定义文案，效果查看：[@alidriver4k](#) | 140U            |
| 彩虹群发、强拉、炒群破解版(送便宜号商地址)                 | 软件下载地址:[网盘地址](https://pan.baidu.com/s/18NYmzhaSKx2x4KnfcAaqNg?pwd=u5vw),使用教程:[视频教程](https://www.youtube.com/watch?v=t09ZIz3k-i4),自助购买:[@autocaihongbot](https://t.me/autocaihongbot?start=gwHypTpEnF84wUi) | ¥200             |
| 搜索机器人源码                 | 有需要自行联系[@tghzsx_bot](https://t.me/tghzsx_bot)进行搜索机器人测试体验 | 10000U             |
| 电报机器人开发                 | 有需要自行联系[@tghzsx_bot](https://t.me/tghzsx_bot) | 根据功能难易度报价            |
<div style="display: flex; justify-content: space-between;">
  <img src="https://i.imgur.com/9E65XRH.png" alt="彩虹群发器破解版免费" style="width: 30%;"/>
  <img src="https://i.imgur.com/9MxAREe.png" alt="彩虹群发器破解版" style="width: 30%;"/>
  <img src="https://i.imgur.com/o32jV8y.png" alt="彩虹群发电报神器" style="width: 30%;"/>
</div>

### 会员 | 能量租赁机器人 【可找我代充36U/年，比机器人要便宜】
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 电报会员自助开通机器人       |   [@kttgvip_bot](https://t.me/kttgvip_bot)  | 自动开通Telegram电报会员机器人，支持USDT、TRX、支付宝、微信等平台开通|
| 能量租赁机器人      | [@trxgd_bot](https://t.me/trxgd_bot)       |一款全自动的能量租赁机器人 |

## 电报切换中文语言

视频参考：https://www.youtube.com/watch?v=-Bz9amW-iZQ

## +86 无法接收验证码问题

视频参考：https://www.youtube.com/watch?v=ErfanyyANUI

### 1. 开通国际漫游

| 运营商 | 短信内容 | 发送号码 |
|--------|----------|----------|
| **移动**   | 发送“11111” | 10629349125637402 |
| **电信**   | 发送“11111” | 1068299708 |
| **联通**   | 发送“11111” | 106829970757 |

### 2. TelegramX

- [TelegramX 官方下载](https://play.google.com/store/apps/details?id=org.thunderdog.challegram)
- [TelegramX 安卓下载（免 Google Play）](https://telegram-x.cn.uptodown.com/android)

### 3. 接码平台

- [SMS 接码平台](https://sms-activate.guru/?ref=2695392)

### 4. Giffgaff 手机卡

- 淘宝口令：`7$nLhL3ujoLr9$:// CZ3148`

### Telegram API申请

官网申请API: https://my.telegram.org/auth?to=apps

网络有问题我这边可以帮忙代申请100%成功，5U或者是30块有需要联系TG:[@banyunpindao](https://t.me/banyunpindao)

| Field         | Value                                    |
|---------------|------------------------------------------|
| App api_id    | 23862859                                 |
| App api_hash  | 9fc6cfff12d0763xxx1125ddb46602a          |
| App title     | zhuanfabotsxxx                              |
| Short name    | zhuanfabotsxxx                              |

### Telegram钱包|虚拟信用卡
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| wallet       |   [@wallet](https://t.me/wallet)  | Telegram官方钱包，支持比特币、USDT和TON的应用内支付|
| okpay      | [@OkayPayBot](https://t.me/OkayPayBot?start=creditCardInvite--6294881820)       |可用于店租（Amazon、Shopify、Shope等）、广告（Facebook、Google等）、云服务、游戏、开发者应用、海淘购物等全场景支付。|

### Telegram空投
| 项目      | 空投地址及说明                                                                                 | 领取条件                     |
| --------- | --------------------------------------------------------------------------------------------- | ---------------------------- |
| PAWS      | [https://t.me/PAWSOG_bot](https://t.me/PAWSOG_bot/PAWS?startapp=oswQUDfd)                     | 基本电报用户都有，领取数量不等 |
| CATS      | [https://t.me/catsgang_bot](https://t.me/catsgang_bot/join?startapp=mrorvC6pDCl1rDGGTvjXd)     | 依据账号活跃度和年份发放      |
| BLUM      | [https://t.me/blum/app](https://t.me/blum/app?startapp=ref_upb27LohdV)                        | 通过游戏和完成任务获取空投    |
| NEBX.IO   | [https://nebx.io](https://nebx.io/login?v=99653959)                                            | 社交媒体任务（签到、关注等）  |

### 指纹多开浏览器【薅羊毛必备】
| 项目      | 官网地址                                                                                 | 介绍                   |
| --------- | --------------------------------------------------------------------------------------------- | ---------------------------- |
| AdsPower     | [https://www.adspower.net](https://share.adspower.net/j0nPEN)                     | 免费版本最多配置5个环境 |
| MoreLogin      | [https://www.morelogin.com](https://www.morelogin.com/?from=AA1ADh2pdRLo)     | 免费2个环境，2个成员      |

### 交易所提币

| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 币安    |   [https://accounts.binance.com](https://accounts.binance.com/zh-CN/register?ref=896983517)   |       币安交易所(持有bnb减免40%手续费)|
| ByBit    |   [https://www.bybit.com/](https://www.bybit.com/invite?ref=4VLKDMW)   |      ByBit交易所(减免30%手续费)|
| 火币    |   [https://www.htx.com](https://www.htx.com.de/zh-cn/v/register/double-invite/?invite_code=xpi6a223&inviter_id=11346560)   |      火币交易所(减免30%手续费)|
| 欧易OKX    |   [https://www.okx.com](https://chouyi.info/join/50253981)   |      欧易交易所(减免30%手续费)|

### 虚拟货币机器人
| **名称**       | **描述**               | **链接**                           |
|-----------------|----------------------|-------------------------------------|
| **Pepebot**     | 中文机器人，国内第一，操作简单 | [Pepebot](https://t.me/pepeboost_sol05_bot?start=ref_05gt6s) |
| **木马机器人**  | 功能最全，速度快，中文，首选，可以跟单 | [木马机器人](https://t.me/diomedes_trojanbot?start=r-tgldy) |
| **Solbot机器人**| 国外喜欢这个，速度快   | [Solbot机器人](https://t.me/SolTradingBot_Asia_Bot?start=NEkB7KuEK) |
| **Cashbot**     | 可以直接跟单聪明钱，中文界面 | [Cashbot](https://t.me/CashCash_trade_bot?start=ref_f05f644b-4) |
| **Robotech**    | 中文机器人，操作简单   | [Robotech](https://t.me/SOL_RoboTechLab_bot?start=Z1sLHV4yJC-ZFgRJ) |
| **Nfdbot**      | 国外排第一             | [Nfdbot](https://t.me/nfd_tron_trade_bot?start=saIVzNrEtj6a) |
| **Sundog机器人**| Sundog开发团队的官方机器人，比较安全，推荐 | [Sundog机器人](https://t.me/sundog_trade_bot?start=aiedUrGoZmTq) |
| **Tronbot**     | 支持中文               | [Tronbot](https://t.me/sunpump?start=invite_DGxUY4iAyK) |
| **Tronsnipebot**| -                    | [Tronsnipebot](https://t.me/Tronsnipebot?start=ref_Ub77NkK9xw) |
| **Nntrx**       | 用于租能量            | [Nntrx](https://t.me/nntrx_bot?start=7202424896) |
| **Pepeboost**   | ETH链机器人           | [Pepeboost](https://t.me/pepeboost_swap_bot?start=ref_04z4et) |
| **BASE链BOT**   | ETH链常用BOT          | [BASE链BOT](https://t.me/Sigma_buyBot?start=ref=7202424896) |
| **大师机器人**  | -                    | [大师机器人](https://t.me/maestro?start=r-tgldy) |
| **Ave机器人**   | -                    | [Ave机器人](https://t.me/AveSniperBot?start=ref_tgldy) |
| **Dbot**        | -                    | [Dbot](https://t.me/sol_dbot?start=ref_18442256) |
| **龙枪**        | -                    | [龙枪](https://t.me/dragun69?start=rich6d8dab5533a2) |

### 常用机器人

🔥Telegram专门的机器人合集🔥：[https://github.com/itgoyo/TelegramBot](https://github.com/itgoyo/TelegramBot)

| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 区块链助手      | [@QueryTokenBot](https://t.me/QueryTokenBot?start=invite_7439567495)       |能量闪租、TRX兑换、地址交易查询、地址实时监听、余额查询、飞机查群|
| 创建自己的机器人      | [@BotFather](https://t.me/BotFather)       |可以创建和管理专属机器人的地方，开发者会获得一个API令牌，用于控制机器人并接入Telegram API  |
| 群管理机器人      | [@nmnmfunbot](https://t.me/nmnmfunbot)       |中文用户使用最多的群管理机器人，几乎什么功能都有  |
| 群管理机器人      | [@GroupHelpBot](https://t.me/GroupHelpBot)       |根据自己群组的需要设定一系列的自动化内容，如欢迎语、跳转到社媒账号或独立站、删除信息、警告用户等  |
| 群管理机器人      | [@WeGroupRobot](https://t.me/WeGroupRobot)       |专为管理和优化群组聊天体验而设计。它可以帮助群组管理员简化日常管理任务，提高群组的互动质量 |
| 方丈群管理机器人      | [@fangzhang_bot](https://t.me/fangzhang_bot)       |新人进群验证、新人进群欢迎词、垃圾信息拦截、自动回复、定时发送、强制订阅、消息统计 |
| 起点交易机器人      | [@qdbot](https://t.me/qdbot?start=invite_533296)       |网络骗子太多，需要担保平台，保证双方利益的交易机器人 |
| 双向机器人      | [@LivegramBot](https://t.me/LivegramBot)       |可以免费创建属于自己的双向机器人，解决账号无法主动发起会话的问题  |
| 按钮机器人      | [@PostBot](https://t.me/PostBot)       | 可以在群组或者频道里面编辑按钮控件，用来挂链接或者打广告的神器 |
| 查特皮皮鸡      | [@ZUOLUOTV_AI_BOT](https://t.me/ZUOLUOTV_AI_BOT)       |基于OpenAI和 Google Cloud AI Platform 的 Anti-Spam机器人，可以有效过滤文字、图片、贴纸等垃圾广告。 |
| 长消息杀手   | [@LongMessageKillerBot](https://t.me/LongMessageKillerBot)        | 最近长消息炸群很多，使用这个长消息杀手机器人可以防止炸群  |
| 广告杀手   | [@GuangGaoShaShouBot](https://t.me/GuangGaoShaShouBot)        | 本机器人专业封杀中文广告内容以及广告号 |
|  频道搬运机器人  | [@msg_get_bot](https://t.me/msg_get_bot?start=K86QAr71)        | 破解频道/群组不允许转发机器人,频道主运营利器|
|  ID查询机器人  | [@username_to_id_bot](https://t.me/username_to_id_bot)        | 查询用户ID、频道ID、群组ID |
|  ID查询机器人  | [@nminfobot](https://t.me/nminfobot)        | 转发一条聊天信息给我，快速查询对方 ID|
|  短信轰炸机器人  | [@Carll_Bomb_bot](https://t.me/Carll_Bomb_bot?start=7439567495)        | 短信轰炸机器人，这你爱的人送上“祝福”。让你爱的人，“夜不能寐”|
|  区块链助手  | [@QueryTokenBot](https://t.me/QueryTokenBot?start=invite_7439567495)        | 用来监听钱包余额变化，防骗必备神器|


#### TG中文群组索引机器人bot
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
|SOSO|[@soso](https://t.me/sosoo?start=a_6294881820)|群组搜索机器人🔍，然后BOT提供关键词相关群组的机器人。可以拉到群组使用。|
| 极搜JiSo | [@jiso](https://t.me/jiso?start=a_6294881820)  | 群组搜索机器人🔍，然后BOT提供关键词相关群组的机器人。可以拉到群组使用。|
| 极搜JiSou     | [@jisou](https://t.me/jisou2bot?start=a_6294881820)  | 群组搜索机器人🔍，然后BOT提供关键词相关群组的机器人。可以拉到群组使用。  |
| ikuaiso     | [@ikuaisobot](https://t.me/ikuaisobot?start=7352210715)  | 帮你找到有趣的群、频道、视频、音乐、电影、新闻！ |
| aiso搜索机器人     | [@aiso](https://t.me/aiso?start=telegram_6294881820)  | 查找群组、频道、影视、音乐或机器人。  |
| 神马索引机器人      | [@smss](https://t.me/smss?start=spread_6294881820)       | 神马索引机器人，可以通过关键词查找  |
| 中文索引   | [@TeleTop123Bot](https://t.me/TeleTop123Bot?start=6294881820)        | 帮助您找到感兴趣的群组、频道和机器人！      |
| TON索引  | [TonCnBot](https://t.me/TonCnBot?start=6294881820)       | 帮助您找到感兴趣的群组、频道和机器人！  |


#### 群组抽奖机器人
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 抽奖助手机器人      | [@tgLotteryBot](https://t.me/tgLotteryBot)       | 抽奖助手机器人  |
| 抽奖助手机器人      | [@LotteryHelperBot](https://t.me/LotteryHelperBot)       | 抽奖助手机器人  |
| 幸运抽奖助手   | [@Grinx_bot](https://t.me/Grinx_bot)        | 幸运抽奖助手      |
| 抽奖机器人      | [@fengdrawbot](https://t.me/fengdrawbot)       | 抽奖机器人  |
| Telegram 抽奖助手      | [@cnLottery_bot](https://t.me/cnLottery_bot)       | Telegram 抽奖助手  |
| Telegram 抽奖活动导航 | [@Lottery_home](https://t.me/Lottery_home) | 想白嫖的推荐关注，想推广群组的在自己群使用bot创建抽奖后可以选择是否推荐到这个频道。 |

#### 协助管理群组机器人验证
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 验证机器人      | [@P4CaptchaBot](https://t.me/P4CaptchaBot)       | 验证机器人，四个汉字验证码  |
| 验证机器人      | [@group_confirmation_bot](https://t.me/group_confirmation_bot)       | 验证机器人，四个汉字验证码  |
| 加群验证,杀广告   | [@tgcnjoincaptchabot](https://t.me/tgcnjoincaptchabot)        | 加群验证,杀广告      |
| reCAPTCHA 验证码      | [@TGreCAPTCHABot](https://t.me/TGreCAPTCHABot)       | 给 Telegram 群组用的 reCAPTCHA 验证码  |
| 加群验证码      | [@jqs7zweibot](https://t.me/jqs7zweibot)       | 加群验证码  |
| 自定义问题加群验证      | [@policr_bot](https://t.me/policr_bot)       | 加群验证,用户可以自定义问题  |
| 欢迎消息，消息自毁，进群验证      | [@FengDoorBot](https://t.me/FengDoorBot)       | 欢迎消息，消息自毁，进群验证  |
| 进群验证问题   | [@orgrobot](https://t.me/orgrobot)        | 进群验证问题,群管可自定义验证问题,以后可能收费      |
| 谷歌人机验证      | [@fuckuspambot](https://t.me/fuckuspambot)       | 过滤机器人已经支持入群的时候使用谷歌人机验证了。  |
| 入群验证bot      | [@shieldy_bot](https://t.me/shieldy_bot)       | 入群验证bot  |
| 加减法运算入群验证   | [@toorucaptchabot](https://t.me/toorucaptchabot)        | 一个简单的加减法运算入群验证机器人      |

#### 欢迎
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 欢迎机器人      | [@RealApolloBot](https://t.me/RealApolloBot)       | 欢迎机器人  |
| 欢迎机器人      | [@WTFisBot](https://t.me/WTFisBot)       | 欢迎机器人  |
| 欢迎机器人   | [@jh0ker_welcomebot](https://t.me/jh0ker_welcomebot)        | 欢迎机器人      |

#### 广告拦截
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 长名广告专杀      | [@adnamekillerbot](https://t.me/adnamekillerbot)       | 长名广告专杀  |
| 限制新群员      | [@AutoRestrictBot](https://t.me/AutoRestrictBot)       | 限制新群员  |
| 删除进出群消息   | [@AntiServiceMessageBot](https://t.me/AntiServiceMessageBot)        | I remove join/leave messages in groups and supergroups.      |

#### 看门
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 看门机器人      | [@WatchDoorBot](https://t.me/WatchDoorBot)       | 可禁止发送指定类型的信息,用于避免恶意举报,官方地址https://hackmd.io/s/BkwAIgrL7  |

#### 昵称
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 忘记设置username提醒      | [@UNameBot](https://t.me/UNameBot)       | 在使用者忘記設定 username 時發送提醒訊息  |
| 监控名字更改记录      | [@SangMata_BOT](https://t.me/SangMata_BOT)       | 放入群组可以监控群里用户名字更改记录  |

#### 骂人
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
| 骂人机器人      | [@the_jbot](https://t.me/the_jbot)       | 骂人机器人  |

#### 下载机器人
| 名字               | 链接                                           | 功能描述                                   |
| :---               | :----:                                         | :---                                       |
| 网易云音乐下载     | [@Music163bot](https://t.me/Music163bot)       | 支持网易云音乐下载                        |
| 抖音 TikTok 视频图集解析 | [@DouYintg_bot](https://t.me/DouYintg_bot)   | 支持抖音、TikTok、X推特、小红书等视频图集解析，支持去水印 |
| 支持推特、微博、小红书、reddit解析 | [@web2album_bot](https://t.me/web2album_bot) | 支持推特、微博、小红书、reddit解析，支持长截图分割 |
| B站、抖音、微博等解析 | [@bilibiliparse_bot](https://t.me/bilibiliparse_bot) | 支持B站、抖音、小红书、推特、Ins、油管、TikTok等解析 |
| 支持多平台解析     | [@douyin_download_bot](https://t.me/douyin_download_bot) | 支持B站、抖音、小红书、推特、Ins、FB、油管等解析 |
| 多平台解析工具     | [@ParsehubBot](https://t.me/ParsehubBot)     | 支持抖音、B站、油管、TikTok、小红书、推特等解析 |
| 支持多个平台下载   | [@icbcbot](https://t.me/icbcbot)             | 支持抖音、TikTok、推特、Ins、微博等平台下载 |
| 妙妙小工具 Beta    | [@GLBetabot](https://t.me/GLBetabot)          | 支持多个平台和网站的下载功能，详细功能见官网 |
| 多平台下载工具     | [@download_it_bot](https://t.me/download_it_bot) | 支持大多数网站下载                       |
| 推特视频下载       | [@twitter_loli_bot](https://t.me/twitter_loli_bot) | 推特视频下载，速度快                     |
| Reddit下载器       | [@reddit_download_bot](https://t.me/reddit_download_bot) | Reddit视频下载器                        |
| 多平台下载工具集   | [@MultiSaverXbot](https://t.me/MultiSaverXbot) | 多个链接支持国外下载网站                |
| B站视频下载       | [@bilifeedbot](https://t.me/bilifeedbot)     | B站下载                                 |
| Pixiv下载          | [@Pixiv_bot](https://t.me/Pixiv_bot)          | Pixiv下载                                |
| 电影搜索机器人     | [@Cctv365bot](https://t.me/Cctv365bot)        | 电影搜索机器人                          |

#### 其他有趣机器人
| 名字     | 链接 | 功能描述     |
| :---        |    :----:   |          :--- |
|PG电子🎮爆币      | [@PGPGSoftbot](https://t.me/PGPGSoftbot?start=10264)       | 爆金币 |
| Dictionary bot      | [@dicbot](https://t.me/dicbot)       | Dictionary bot that gives definitions of words.  |
| Chatbot      | [@strangybot](https://t.me/strangybot)       | A chatbot that you can talk to.  |
| Quiz bot   | [@QuizBot](https://t.me/QuizBot)        | Create and take quizzes.      |
| Telegram client      | [@Pwrtelegram](https://t.me/Pwrtelegram)       | Telegram client with additional features.  |
| Weather bot      | [@WeatherBot](https://t.me/WeatherBot)       | Provides weather updates.  |
| 图片时间提醒      | [@sticker_time_bot](https://t.me/sticker_time_bot)       | 每小时发送一张图片提醒时间  |
| 删除带链接消息   | [@AntiHyperlinkBot](https://t.me/AntiHyperlinkBot)        | removes all messages which contain links      |
| 删除阿拉伯文消息      | [@AntiArabicScriptBot](https://t.me/AntiArabicScriptBot)       | removes all messages which contain arabic script  |
| 保护群组防止垃圾信息      | [@SpamMeNotBot](https://t.me/SpamMeNotBot)       | protects your group from spam/flood attacks  |
| 删除含命令消息   | [@AntiCommandBot](https://t.me/AntiCommandBot)        | removes all messages which contain a /command      |
| More useful bots for group owners      | [@GroupOwnerBot](https://t.me/GroupOwnerBot)       | More useful bots for group owners  |
| 文件与链接检测      | [@drwebbot](https://t.me/drwebbot)       | Dr.Web（大蜘蛛）公司推出了一个实验性的 Telegram Bot，它可以检查网页链接和文件，并在包含威胁时发出警告。单文件限制20M（Aquamarine）  |
| 群组清理大师      | [@GroupCleanupMasterBot](https://t.me/GroupCleanupMasterBot)       | 群组清理大师智能清除广告  |
| 删除含有黑名单词的发言   | [@grep_robot](https://t.me/grep_robot)        | 删除含有黑名单词的发言      |
| 广告杀手      | [@LookOnbot](https://t.me/LookOnbot)       | 广告杀手,只需要删除消息即可协助群管理清除广告,另有众多实用功能,包括禁止关联频道置顶,封杀病毒文件等  |
| 广告链接拦截      | [@ProtectronBot](https://t.me/ProtectronBot)       | 删除广告链接,短链接,转发,进出群消息,设置关键字黑名单,禁止刷屏,删除色情图片等,误杀比较多.  |
| 发言频率限制   | [@freqrobot](https://t.me/freqrobot)        | 限制群员发言频率      |
| 广告终结者      | [@adzhongjiezhe_bot](https://t.me/adzhongjiezhe_bot)       | 广告终结者,通过设置关键字来删除违规消息  |
| 禁止关联频道置顶      | [@DiscussUnpinBot](https://t.me/DiscussUnpinBot)       | 禁止关联频道群置顶  |
| 自动删除exe、scr、com、cpl后缀的文件   | [@noexebot](https://t.me/noexebot)        | 自动删除exe、scr、com、cpl后缀的文件      |
| 删除进群24小时新人转发,图片等信息      | [@daysandbox_bot](https://t.me/daysandbox_bot)       | 删除进群24小时新人转发,图片等信息  |
| 删除特定类型的信息   | [@watchdog_robot](https://t.me/watchdog_robot)        | 删除特定类型的信息,例如链接,贴纸,图片,语音信息,文件等等      |
| 删除阿拉伯语和波斯语信息      | [@noarab_bot](https://t.me/noarab_bot)       | 删除阿拉伯语和波斯语信息  |
| 删除指定语言的信息      | [@lang_blocker_bot](https://t.me/lang_blocker_bot)       | 删除指定语言的信息  |
| 禁止群聊天   | [@HushRobot](https://t.me/HushRobot)        | 禁止群聊天      |
| 删除进群退群提示信息      | [@joinhider_bot](https://t.me/joinhider_bot)       | 删除进群退群提示信息  |
| 删除欢迎信息      | [@nohello_robot](https://t.me/nohello_robot)       | 删除欢迎信息  |
| 统计群组发言数   | [@jung2_bot](https://t.me/jung2_bot)        | 统计群组中用户的发言数      |
| 统计秘书      | [@FengStatsBot](https://t.me/FengStatsBot)       | 统计秘书,本秘书做群中各种统计，发言次数等  |
| 管理通知      | [@MasterTagAlertBot](https://t.me/MasterTagAlertBot)       | 管理通知  |
| IMDb查电影信息   | [@imdb](https://t.me/imdb)        | IMDb查电影信息      |
| URL转TG档案      | [@uploadbot](https://t.me/uploadbot)       | 神奇的普通URL網址轉TG檔案，单个文件限制500M,每天限制1GB。如果想更多空間可以買VIP  |
| 提供工作机会      | [@jobs_bot](https://t.me/jobs_bot)       | telegram官方提供工作机会  |
| 临时邮箱机器人      | [@sms24_me](https://t.me/sms24_me)       | 提供电话号码用于接收短信  |
| 群组管理      | [http://teleme.io](http://teleme.io)       | TeleMe 是一款功能强大又方便好用的 Telegram 社群管理 Bot 机器人,收费,有免费额度  |
| 搜索机器人      | [@SearcheeBot](https://t.me/SearcheeBot)       | TG频道搜索机器人  |
| bot搜索   | [@BotListBot](https://t.me/BotListBot)        | bot搜索      |
| 查找bot,频道,群,贴纸等      | [@ExploreTelegramBot](https://t.me/ExploreTelegramBot)       | 查找bot,频道,群,贴纸等  |
| 群管bot      | [@GroupHelpBot](https://t.me/GroupHelpBot)       | 群管bot,除了常用的命令,还可以查看近期不活跃名单,设置关键字自动回复  |
| 生成私聊机器人   | [@LimitatiBot](https://t.me/LimitatiBot)        | 生成私聊机器人      |
| 给管理员发消息      | [@callAdminsBot](https://t.me/callAdminsBot)       | 给管理员发消息  |
| 黑名单机器人      | [@hexlightning_bot](https://t.me/hexlightning_bot)       | 台灣人自己的黑名單機器人  |
| 创建临时邮箱机器人   | [@DropmailBot](https://t.me/DropmailBot)        | 临时邮箱顾名思义是个临时的匿名邮箱，可以用来保护个人隐私和防止垃圾邮件      |
| 创建临时邮箱机器人   | [@RustRssBot](https://t.me/RustRssBot)        | 中文 Telegram RSS 机器人     |
| 解除频道消息在群组的置顶   | [@areply_bot](https://t.me/areply_bot)        | 自动解除频道消息在群组的同步置顶，附带群组日常维护常用小功能  |

### 群组 Group

###### 京豆

*   jdShareCode:[https://t.me/jdShareCode](https://t.me/jdShareCode)
*   PKC皮卡车:[https://t.me/topstyle996](https://t.me/topstyle996)
*   Leeco-雪花社:[https://t.me/xuehuashe](https://t.me/xuehuashe)

###### 脚本

*   Bigo社区群:[https://t.me/bigo_tool](https://t.me/bigo_tool)
*   Fragment账号实时报价:[https://t.me/Fragment_Monitor](https://t.me/Fragment_Monitor)

###### 翻墙

*   机场VPN导航站:[https://jichangvpn.github.io/](https://jichangvpn.github.io/)
*   每日免费节点:[https://t.me/autofreevpn](https://t.me/autofreevpn)
*   Shadowsocks&Clash:[https://t.me/shadowsocks_clash](https://t.me/shadowsocks_clash)
*   不良林:[https://t.me/buliang00](https://t.me/buliang00)
*   搬瓦工 (BandwagonHost):[https://t.me/BandwagonHostUsers](https://t.me/BandwagonHostUsers)
*   Surge 交流:[https://t.me/loveapps](https://t.me/loveapps)
*   Surge Pro:[https://t.me/SurgePro](https://t.me/SurgePro)
*   Quantumult X:[https://t.me/QuanXApp](https://t.me/QuanXApp)
*   Quantumult:[https://t.me/quantumult](https://t.me/quantumult)
*   Loon:[https://t.me/Loon0x00](https://t.me/Loon0x00)
*   LanceX:[https://t.me/lancex_app](https://t.me/lancex_app)
*   Quantumult X、Surge、Loon 的脚本讨论:[https://t.me/joinchat/JikZ61Y-WyLUu6dBFPfu6w](https://t.me/joinchat/JikZ61Y-WyLUu6dBFPfu6w)
*   thor，Quantumult X，小火箭 JSBox 交流群:[https://t.me/weixiaoge777](https://t.me/weixiaoge777)
*   Nexitally:[https://t.me/nexitallyusers](https://t.me/nexitallyusers)
*   ImmTelecom:[https://t.me/immtelecom_chat](https://t.me/immtelecom_chat)
*   科学上网技术研究会:[https://t.me/kxswjs](https://t.me/kxswjs)
*   科学上网，科技分享:[https://t.me/qiankeji](https://t.me/qiankeji)
*   老王用户群:[https://t.me/wangvpn_users](https://t.me/wangvpn_users)
*   老王讨论群:[https://t.me/wangvpn_user_chat](https://t.me/wangvpn_user_chat)
*   几鸡:[https://t.me/ngcss](https://t.me/ngcss)
*   嘿嘿嘿:[https://t.me/hellcell321](https://t.me/hellcell321)
*   SSPanel 机场联盟:[https://t.me/SSUnion](https://t.me/SSUnion)
*   Air-Universe 开源后端交流群:[https://t.me/Air_Universe](https://t.me/Air_Universe)
*   LAMP 交流群:[https://t.me/qiushui2018](https://t.me/qiushui2018)
*   BGP 测速:[https://t.me/hxisj8whsv](https://t.me/hxisj8whsv)
*   品云:[https://t.me/PinYunYes](https://t.me/PinYunYes)
*   ShadowsocksR 讨论组:[https://t.me/ssrunofficial](https://t.me/ssrunofficial)
*   ShadowsocksR 讨论组 2 群:[https://t.me/chatssr](https://t.me/chatssr)
*   Netch 游戏加速工具:[https://t.me/Netch_Discuss_Group](https://t.me/Netch_Discuss_Group)
*   Pharos Pro For iOS:[https://t.me/Shadow_x_user_support](https://t.me/Shadow_x_user_support)
*   Pharos Pro For Android:[https://t.me/joinchat/EthDYRQ80Clo_dj8e3PJnQ](https://t.me/joinchat/EthDYRQ80Clo_dj8e3PJnQ)
*   ShadowRay:[https://t.me/ShadowRay](https://t.me/ShadowRay)
*   Project V(V2Ray):[https://t.me/projectv2ray](https://t.me/projectv2ray)
*   Project X(Xray):[https://t.me/projectXray](https://t.me/projectXray)
*   V2fly Official:[https://t.me/v2fly_chat](https://t.me/v2fly_chat)
*   V2Fly #Off-Topic:[https://t.me/joinchat/GhXX_0zQFLOkjy9z81eQqg](https://t.me/joinchat/GhXX_0zQFLOkjy9z81eQqg)
*   v2rayN&G:[https://t.me/v2rayN](https://t.me/v2rayN)
*   NobyDa Script:[https://t.me/joinchat/JtzRlVY-WyJPDavvhKjrbw](https://t.me/joinchat/JtzRlVY-WyJPDavvhKjrbw)
*   老毛子 Padavan 固件自助交流群:[https://t.me/pdcn2](https://t.me/pdcn2)
*   老毛子 Padavan 固件 iOS 自助交流群:[https://t.me/pdcn3](https://t.me/pdcn3)
*   Wingy Halal Group:[https://t.me/wingytg](https://t.me/wingytg)
*   WireGuard:[https://t.me/WireGuard](https://t.me/WireGuard)
*   VPN 讨论群:[https://t.me/gouwu](https://t.me/gouwu)
*   SockBoom 咕咕咕交流群:[https://t.me/sockboom](https://t.me/sockboom)
*   Python 云 - 一个学习 py 的公益机场:[https://t.me/pythonyun](https://t.me/pythonyun)
*   NyanCAT Group:[https://t.me/NyanCaaaat](https://t.me/NyanCaaaat)
*   梦迪 mdssCloud:[https://t.me/mdssios](https://t.me/mdssios)
*   Catnet:[https://t.me/justanode_official](https://t.me/justanode_official)
*   次元链接:[https://t.me/cylink](https://t.me/cylink)
*   MunClolud:[https://t.me/joinchat/E5UhwEOdb4UtA_VbonoxDw](https://t.me/joinchat/E5UhwEOdb4UtA_VbonoxDw)
*   Flysocks-Server:[https://t.me/flysocks](https://t.me/flysocks)
*   loriCloud:[https://t.me/loricloud](https://t.me/loricloud)
*   盈科數碼動力 Pacific Century CyberWorks Limited:[https://t.me/ssrcloud](https://t.me/ssrcloud)
*   THE.SSR 官方售后群 (BLINKLOAD):[https://t.me/thessrgroup](https://t.me/thessrgroup)
*   永久公益机场:[https://t.me/AC_FFree](https://t.me/AC_FFree)
*   大水比交流群:[https://t.me/hxisj8whsv](https://t.me/hxisj8whsv)
*   大佬吹牛群:[https://t.me/xddos0](https://t.me/xddos0)
*   少数人 TG 交流群:[https://t.me/shaoshurenx](https://t.me/shaoshurenx)
*   DLK 的奔放交流时间:[https://t.me/dlkvpn](https://t.me/dlkvpn)
*   泡泡云:[https://t.me/popocloud](https://t.me/popocloud)
*   Mac 翻墙・SpechtLite 交流群:[https://t.me/SpechtLite](https://t.me/SpechtLite)
*   GFW 吐槽 && 翻墙方法讨论:[https://t.me/DiscussCrossGFW](https://t.me/DiscussCrossGFW)
*   VPS 全球主機交流:[https://t.me/VPSchat](https://t.me/VPSchat)
*   BIS 科学上网:[https://t.me/BISproject](https://t.me/BISproject)
*   Kitsunebi 交流:[https://t.me/Kitsunebi_funs](https://t.me/Kitsunebi_funs)
*   精品免费翻墙 app 推荐:[https://t.me/fuckyougfw](https://t.me/fuckyougfw)
*   SSTap Rule:[https://t.me/SSTapRule](https://t.me/SSTapRule)
*   几鸡 - 小圈自用公益机场:[https://t.me/lisuanlaoji](https://t.me/lisuanlaoji)
*   vAgent 云计算加速服务:[https://t.me/crossgreatfirewall](https://t.me/crossgreatfirewall)
*   ss panel v3 mod 非官方水群:[https://t.me/SSUnion](https://t.me/SSUnion)
*   小布吉岛闲聊群:[https://t.me/bujidaochat](https://t.me/bujidaochat)
*   OKAB3 吹水:[https://t.me/OKAB3Script](https://t.me/OKAB3Script)
*   Official Geph Users 迷霧通官方用戶群:[https://t.me/gephusers](https://t.me/gephusers)
*   ExCloud:[https://t.me/excloud](https://t.me/excloud)
*   AK’s Tech Studio:[https://t.me/joinchat/GnoDABmvn-48g2PpaySbeQ](https://t.me/joinchat/GnoDABmvn-48g2PpaySbeQ)
*   章鱼哥的 SSPanel 之家:[https://t.me/woaizyg](https://t.me/woaizyg)
*   枫之谷加速:[https://t.me/fzgjs](https://t.me/fzgjs)
*   VPS 信号旗情报本部:[https://t.me/vps_xinhaoqi](https://t.me/vps_xinhaoqi)
*   小火箭 / 圈叉非官方群，Shadowrocke/QX:[https://t.me/shadowrocket_unofficial](https://t.me/shadowrocket_unofficial)
*   中信加速器 VPN 官方群:[https://t.me/zxfast](https://t.me/zxfast)
*   火箭写书:[https://t.me/woicesu](https://t.me/woicesu)
*   SSRSpeed N 使用交流:[https://t.me/SSRSpeedN](https://t.me/SSRSpeedN)
*   iQZone:[https://t.me/iQ_Zone](https://t.me/iQ_Zone)

###### 软件

*   Microsoft users:[https://t.me/Microsofthelp](https://t.me/Microsofthelp)
*   捷径 Shortcuts:[https://t.me/SiriShortcuts](https://t.me/SiriShortcuts)
*   捷径社区:[https://t.me/shortcuts_cn](https://t.me/shortcuts_cn)
*   Snipaste:[https://t.me/joinchat/BGyWwD9ZNqE3pLbhXc-VgQ](https://t.me/joinchat/BGyWwD9ZNqE3pLbhXc-VgQ)
*   Snipaste Discuss:[https://t.me/joinchat/BGyWwEDqrqiwizDA6gt16g](https://t.me/joinchat/BGyWwEDqrqiwizDA6gt16g)
*   Price Tag:[https://t.me/pricetagapp](https://t.me/pricetagapp)
*   App 种草群:[https://t.me/appfoundgroup](https://t.me/appfoundgroup)
*   版本控:[https://t.me/nextnb](https://t.me/nextnb)
*   Chrome:[https://t.me/ChromeCN](https://t.me/ChromeCN)
*   MWeb 及相关讨论:[https://t.me/mwebapp](https://t.me/mwebapp)
*   MOZE 官方群:[https://t.me/mozeapp](https://t.me/mozeapp)
*   岁寒输入法交流:[https://t.me/SuiHanIME](https://t.me/SuiHanIME)
*   HyperApp:[https://t.me/hyperapp](https://t.me/hyperapp)
*   Docker:[https://t.me/dockertutorial](https://t.me/dockertutorial)
*   Pin:[https://t.me/PinTG](https://t.me/PinTG)
*   奇点:[https://t.me/jidian](https://t.me/jidian)
*   Thor:[https://t.me/thorshu](https://t.me/thorshu)
*   Thor HTTP Sniffer:[https://t.me/thoranubis](https://t.me/thoranubis)
*   Thor/HTTP/JSBox/ 捷径 / Cydia 交流群:[https://t.me/yqc_666](https://t.me/yqc_666)
*   Pythonista 3:[https://t.me/Pythonista3jiaoliuqun](https://t.me/Pythonista3jiaoliuqun)
*   iTools:[https://t.me/toolinbox](https://t.me/toolinbox)
*   X.cat:[https://t.me/PcatApp](https://t.me/PcatApp)
*   Drafts:[https://t.me/drafts4](https://t.me/drafts4)
*   Aria2 中文交流群:[https://t.me/Aria2_CN](https://t.me/Aria2_CN)
*   Lucis（优雅的第三方 Tumblr 客户端）:[https://t.me/LucisApp](https://t.me/LucisApp)
*   LyricsX:[https://t.me/LyricsXTestFlight](https://t.me/LyricsXTestFlight)
*   PureWriter’s Friends:[https://t.me/purewriter/](https://t.me/purewriter/)
*   码农群英会:[https://t.me/devmanman](https://t.me/devmanman)
*   EOS:[https://t.me/EOSproject](https://t.me/EOSproject)
*   Sifter:[https://t.me/sifterapp](https://t.me/sifterapp)
*   IINA 中文:[https://t.me/IINAUsersZH](https://t.me/IINAUsersZH)
*   IINA:[https://t.me/IINAUsers](https://t.me/IINAUsers)
*   RSSHub:[https://t.me/rsshub](https://t.me/rsshub)
*   PPHub 官方群:[https://t.me/joinchat/Jn89QxI2MWt9hgTLQQW2Gg](https://t.me/joinchat/Jn89QxI2MWt9hgTLQQW2Gg)
*   Cuto 壁纸:[https://t.me/joinchat/BC6PtD89sEGgHKR28OtQVA](https://t.me/joinchat/BC6PtD89sEGgHKR28OtQVA)
*   UpperSoft - 讨论组:[https://t.me/UpperSoftDiscuss](https://t.me/UpperSoftDiscuss)
*   Mac 玩儿法茶馆:[https://t.me/waerfa](https://t.me/waerfa)
*   APP喵-阿喵软件资源共享:[https://t.me/appmew](https://t.me/appmew)
*   软件技术资源共享:[https://t.me/SharedResourcesplus](https://t.me/SharedResourcesplus)
*   LIHAI 分享:[https://t.me/lihaiba](https://t.me/lihaiba)
*   TelePlus 官方討論組:[https://t.me/TelePlus_Group](https://t.me/TelePlus_Group)
*   MK 播放器:[https://t.me/MKPlayerApp](https://t.me/MKPlayerApp)
*   畅邮（Cymail）电子邮箱客户端:[https://t.me/cyemail](https://t.me/cyemail)
*   记账应用讨论:[https://t.me/accountingapps](https://t.me/accountingapps)
*   Mixin Network (XIN):[https://t.me/MixinCommunity](https://t.me/MixinCommunity)
*   52 破解信息:[https://t.me/wuaipojie](https://t.me/wuaipojie)
*   Launch Center Pro 交流分享:[https://t.me/lcpapp](https://t.me/lcpapp)
*   Reddigram:[https://t.me/reddigram](https://t.me/reddigram)
*   Nicegram Chat:[https://t.me/nicegramchat](https://t.me/nicegramchat)
*   AdGuard Chat [EN]:[https://t.me/adguard_en](https://t.me/adguard_en)
*   Adguard [CN]:[https://t.me/adguard_cn](https://t.me/adguard_cn)
*   AdGuard 【中文】:[https://t.me/AdGuard_chinese](https://t.me/AdGuard_chinese)
*   Gridea 群组:[https://t.me/joinchat/IDY0ahRqb8NPodv95BNpBg](https://t.me/joinchat/IDY0ahRqb8NPodv95BNpBg)
*   Office Tool Group:[https://t.me/joinchat/GdsEL0ejcWZ-T-koyW4Wug](https://t.me/joinchat/GdsEL0ejcWZ-T-koyW4Wug)
*   Excel 学习群:[https://t.me/excellearner](https://t.me/excellearner)
*   VShareCloud:[https://t.me/VShareCloud](https://t.me/VShareCloud)
*   MoonFM:[https://t.me/joinchat/FLWvJhDhXGAQO5SGDg87nw](https://t.me/joinchat/FLWvJhDhXGAQO5SGDg87nw)
*   Telegreat 中文支援區:[https://t.me/TelegreatX](https://t.me/TelegreatX)
*   Instagram:[https://t.me/joinchat/AAAAAFL_lXy0yPL754j5CQ](https://t.me/joinchat/AAAAAFL_lXy0yPL754j5CQ)
*   PanDownload 交流群:[https://t.me/joinchat/Lz9fSlOgUUyinc5N7Gv6tg](https://t.me/joinchat/Lz9fSlOgUUyinc5N7Gv6tg)
*   APKs, ROMs & Tools:[https://t.me/r3l3as3s](https://t.me/r3l3as3s)
*   dotPlayer 小点播放器:[https://t.me/dotplayer](https://t.me/dotplayer)
*   期待 APP:[https://t.me/angeliachat](https://t.me/angeliachat)
*   Elpass:[https://t.me/ElpassApp](https://t.me/ElpassApp)
*   uTools:[https://t.me/u_tools](https://t.me/u_tools)
*   ttte for Twitter:[https://t.me/ttteapp](https://t.me/ttteapp)
*   Here 内测群:[https://t.me/HereApp](https://t.me/HereApp)
*   Pigeon Insiders:[https://t.me/pigeon_app](https://t.me/pigeon_app)
*   VNoteX:[https://t.me/vnotex](https://t.me/vnotex)
*   VVebo 官方群:[https://t.me/vvebogroup](https://t.me/vvebogroup)
*   VVeboX 非官方群:[https://t.me/VVeboX_unofficial](https://t.me/VVeboX_unofficial)
*   GBox 官方交流群:[https://t.me/GBoxTG](https://t.me/GBoxTG)
*   GBox Official:[https://t.me/GBoxOfficial](https://t.me/GBoxOfficial)
*   Transno:[https://t.me/transnousergroup](https://t.me/transnousergroup)
*   FastClip:[https://t.me/fastclipchat](https://t.me/fastclipchat)
*   Stack Insiders:[https://t.me/stack_app](https://t.me/stack_app)
*   pyTelegramBotAPI:[https://t.me/joinchat/Bn4ixj84FIZVkwhk2jag6A](https://t.me/joinchat/Bn4ixj84FIZVkwhk2jag6A)
*   CC 来电拦截:[https://t.me/ccblocker](https://t.me/ccblocker)
*   Subs - subscriptions tracker:[https://t.me/app_subs](https://t.me/app_subs)
*   时光软件:[https://t.me/sgxxqg](https://t.me/sgxxqg)
*   Scriptable 交流群:[https://t.me/Scriptable_JS](https://t.me/Scriptable_JS)
*   QPomelo Apps:[https://t.me/qpomelo_apps](https://t.me/qpomelo_apps)
*   Hamibot:[https://t.me/HamibotChat](https://t.me/HamibotChat)
*   Anti Revoke Chat:[https://t.me/AntiRevokeChat](https://t.me/AntiRevokeChat)
*   简悦 - SimpRead:[https://t.me/simpreadgroup](https://t.me/simpreadgroup)
*   flomo 浮墨卡片笔记:[https://t.me/flomoapp](https://t.me/flomoapp)
*   ZOE:[https://t.me/ZOEAPP](https://t.me/ZOEAPP)
*   Mac & PC 平台上的视频播放器 (IINA、mpv、madVR、Infuse、Movist、VLC 等):[https://t.me/VideoPlayerAndDisplay](https://t.me/VideoPlayerAndDisplay)
*   App Privacy Insights Official Group:[https://t.me/joinchat/66CSVhKAs3pmYTQ1](https://t.me/joinchat/66CSVhKAs3pmYTQ1)
*   钛盘:[https://t.me/joinchat/nc7xna7GlBo5MjBl](https://t.me/joinchat/nc7xna7GlBo5MjBl)
*   DEVONthink Chinese:[https://t.me/DEVONthink](https://t.me/DEVONthink)
*   Filebox 官方群:[https://t.me/FileboxApp](https://t.me/FileboxApp)

###### 社群

*   币圈日报:[https://t.me/bidaily](https://t.me/bidaily)
*   币安官方中文群:[https://t.me/BinanceChinese](https://t.me/BinanceChinese)
*   大漂亮的小伙伴:[https://t.me/giantcutie6688](https://t.me/giantcutie6688)
*   Vultr 中文社群:[https://t.me/vultr_group](https://t.me/vultr_group)
*   Newlearner 水群:[https://t.me/NewlearnerGroup](https://t.me/NewlearnerGroup)
*   科技花:[https://t.me/zaihuachat](https://t.me/zaihuachat)
*   谷歌交流社区・科技圈:[https://t.me/GoogleFans](https://t.me/GoogleFans)
*   Bark反馈群:[https://t.me/joinchat/OsCbLzovUAE0YjY1](https://t.me/joinchat/OsCbLzovUAE0YjY1)
*   逗比根据地:[https://t.me/doubi](https://t.me/doubi)
*   中文输入法爱好者群:[https://t.me/IME_zhCN](https://t.me/IME_zhCN)
*   少数派 sspai 社群 非官方:[https://t.me/sspai_group](https://t.me/sspai_group)
*   iBeta 尝鲜派 官方用户讨论群:[https://t.me/ibetame](https://t.me/ibetame)
*   库克的后厨 Cook’s Kitchen:[https://t.me/OnlineAppleUserGroup](https://t.me/OnlineAppleUserGroup)
*   沉浸式翻译讨论:[https://t.me/+rq848Z09nehlOTgx](https://t.me/+rq848Z09nehlOTgx)
*   科技无国界:[https://t.me/LifeAnaTech](https://t.me/LifeAnaTech)
*   赚客吧 有奖一起赚:[https://t.me/zuanke8](https://t.me/zuanke8)
*   Apple Watch 大集合:[https://t.me/apple_watch](https://t.me/apple_watch)
*   Apple TV+:[https://t.me/AppleTVPlus](https://t.me/AppleTVPlus)
*   Apple Arcade CN:[https://t.me/applearcadecn](https://t.me/applearcadecn)
*   Apple 用户社群:[https://t.me/appleusergroup_tg](https://t.me/appleusergroup_tg)
*   TVBox:[https://t.me/TVbox888](https://t.me/TVbox888)
*   三星手机交流:[https://t.me/samsung_cn](https://t.me/samsung_cn)
*   智能手机讨论组:[https://t.me/M_Phone](https://t.me/M_Phone)
*   小米玩机交流群:[https://t.me/xiaomi6666](https://t.me/xiaomi6666)
*   飞享一刻｜频道:[https://t.me/w37fhy](https://t.me/w37fhy)
*   mimi:[https://t.me/Orz_mini](https://t.me/Orz_mini)
*   みなもと しずか:[https://t.me/Orz_zayu](https://t.me/Orz_zayu)
*   程序员技术资源分享群 (陈皓 (左耳朵耗子) 创建的群):[https://t.me/joinchat/FwAZpxdwmTHP2W1sPydPAQ](https://t.me/joinchat/FwAZpxdwmTHP2W1sPydPAQ)
*   高可用技术研究:[https://t.me/joinchat/FiMK0A5tQhJxLu9tBb0QTA](https://t.me/joinchat/FiMK0A5tQhJxLu9tBb0QTA)
*   Rust 众:[https://t.me/rust_zh](https://t.me/rust_zh)
*   东京 IT 技术者交流群:[https://t.me/TokyoIT](https://t.me/TokyoIT)
*   PixelExperience - Official chat:[https://t.me/pixelexperiencechat](https://t.me/pixelexperiencechat)
*   GIF 群聚地:[https://t.me/GIFgroupTW](https://t.me/GIFgroupTW)
*   貼圖群 Sticker Group:[https://t.me/StickerGroup](https://t.me/StickerGroup)
*   V2EX 后花园:[https://t.me/joinchat/Bg3MFjv5FgYrWI0WqHDo8Q](https://t.me/joinchat/Bg3MFjv5FgYrWI0WqHDo8Q)
*   V2EX 后花园 v2.0:[https://t.me/goV2EX](https://t.me/goV2EX)
*   V2EX 讨论群:[https://t.me/V2EXPro](https://t.me/V2EXPro)
*   Appinn Talk (小众软件):[https://t.me/appinn](https://t.me/appinn)
*   Setapp 开车群:[https://t.me/joinchat/AacydhT79JJBmDj68rCC9w](https://t.me/joinchat/AacydhT79JJBmDj68rCC9w)
*   BIGdongdongGroup:[https://t.me/bigdongdongGroup](https://t.me/bigdongdongGroup)
*   YouTube—ImShuker:[https://t.me/shukerz](https://t.me/shukerz)
*   Notion 中文社区:[https://t.me/Notionso](https://t.me/Notionso)
*   电报人:[https://t.me/three001](https://t.me/three001)
*   Google Drive 无限容量:[https://t.me/google_drive](https://t.me/google_drive)
*   跳蚤市场 - 科学上网交流等:[http://t.me/PharosMarketShopping](http://t.me/PharosMarketShopping)
*   普通休闲书籍资源:[http://t.me/bookusefor4](http://t.me/bookusefor4)
*   读舍 - 享受阅读时光:[https://t.me/shufm](https://t.me/shufm)
*   写作交流:[https://t.me/writing_discuss](https://t.me/writing_discuss)
*   iGame 游戏交流群:[https://t.me/gamecn](https://t.me/gamecn)
*   电影爱好者交流组:[https://t.me/Moviemarket_group](https://t.me/Moviemarket_group)
*   Emby 终点站:[https://t.me/EmbyPublic](https://t.me/EmbyPublic)
*   PayPal 交流群:[http://t.me/paypal_us](http://t.me/paypal_us)
*   编程随想读者群:[https://t.me/programthinkreader](https://t.me/programthinkreader)
*   码力全开 Friends:[http://t.me/forcecoder](http://t.me/forcecoder)
*   OP 编译官方大群:[https://t.me/joinchat/JhKgAA6Hx1uiihA7RaTW1w](https://t.me/joinchat/JhKgAA6Hx1uiihA7RaTW1w)
*   OpenWrt-flippy:[https://t.me/joinchat/GxqUyxzQCFgf4KEcXxee3Q](https://t.me/joinchat/GxqUyxzQCFgf4KEcXxee3Q)
*   OpenWRT LEDE/Wireless Routers:[https://t.me/OpenWRT_Routers](https://t.me/OpenWRT_Routers)
*   Flippy_Openwrt:[https://t.me/openwrt_flippy](https://t.me/openwrt_flippy)
*   koolshare OpenWRT X64:[https://t.me/joinchat/ERO9vEMMVu1dzQ-F8nP6kA](https://t.me/joinchat/ERO9vEMMVu1dzQ-F8nP6kA)
*   老毛子 Padavan 固件自助交流群:[http://t.me/pdcn2](http://t.me/pdcn2)
*   老毛子 Padavan 固件 IOS 自助交流群:[http://t.me/pdcn3](http://t.me/pdcn3)
*   安卓手机交流圈:[https://t.me/androidsee](https://t.me/androidsee)
*   Google Fi 交流群:[https://t.me/google_fi](https://t.me/google_fi)
*   字谈字畅听众群:[https://t.me/TypeChat](https://t.me/TypeChat)
*   Ruby 中文圈:[https://t.me/rubycn](https://t.me/rubycn)
*   polyhedron:[https://t.me/polyhedron](https://t.me/polyhedron)
*   聽世界:[https://t.me/listentotheworld](https://t.me/listentotheworld)
*   NickTalk:[https://t.me/nicktalk](https://t.me/nicktalk)
*   iTunes Gift Card:[http://t.me/iTunesGift](http://t.me/iTunesGift)
*   iOS:[https://t.me/iOSdevotee](https://t.me/iOSdevotee)
*   macOS 交流组:[https://t.me/macoser](https://t.me/macoser)
*   iPadOS 交流群:[https://t.me/iPadOS](https://t.me/iPadOS)
*   苹果派群组:[https://t.me/iOS1314](https://t.me/iOS1314)
*   黑苹果与白苹果用户交流群:[https://t.me/Balancer996](https://t.me/Balancer996)
*   synology / 黑群晖用户交流群:[https://t.me/nasfan](https://t.me/nasfan)
*   GroupHub_Chat:[https://t.me/GroupHub_Chat](https://t.me/GroupHub_Chat)
*   中国数字时代读者群:[https://t.me/cdtchinese](https://t.me/cdtchinese)
*   Google Voice 交流群:[https://t.me/googlevoice](https://t.me/googlevoice)
*   Google Voice 互拨交流群:[https://t.me/zh_GV](https://t.me/zh_GV)
*   Google Fans Club 中文:[https://t.me/googlecn](https://t.me/googlecn)
*   M-Team official chat - Chinese:[https://t.me/M_Team_Chat](https://t.me/M_Team_Chat)
*   Google 交流群:[https://t.me/GoogleFans](https://t.me/GoogleFans)
*   NAS 私有云技术交流:[https://t.me/NASteam](https://t.me/NASteam)
*   路由器固件玩家群:[https://t.me/sbxsw](https://t.me/sbxsw)
*   Java 编程语言:[https://t.me/Javaer](https://t.me/Javaer)
*   Java Programming Chat:[http://t.me/javaprogrammingchat](http://t.me/javaprogrammingchat)
*   Android Develop 中文讨论群:[https://t.me/AndroidDevCn](https://t.me/AndroidDevCn)
*   Android Delicious:[https://t.me/AndroidDiscuss](https://t.me/AndroidDiscuss)
*   Geeks Chat:[https://t.me/geeksChat](https://t.me/geeksChat)
*   Nintendo Switch 闲聊群:[https://t.me/NintendoSwitchCN](https://t.me/NintendoSwitchCN)
*   CoolApk World 酷安:[https://t.me/Riocoolapk](https://t.me/Riocoolapk)
*   酷友交流群:[https://t.me/coolapkchina](https://t.me/coolapkchina)
*   ZeroNet[zh]:[https://t.me/joinchat/AAAAAAtSeltSs7ffxR0wzw](https://t.me/joinchat/AAAAAAtSeltSs7ffxR0wzw)
*   Beijing GNU/Linux User Group:[https://t.me/beijinglug](https://t.me/beijinglug)
*   MAT - 广场（My Android Tools）:[https://t.me/MyAndroidTools](https://t.me/MyAndroidTools)
*   美剧交流群:[https://t.me/SSKMJBTS](https://t.me/SSKMJBTS)
*   Tg 攝影社群:[https://t.me/photographyintelegram](https://t.me/photographyintelegram)
*   知日讀者群:[https://t.me/zhijapan](https://t.me/zhijapan)
*   加密货币与区块链讨论群:[https://t.me/onBlockchain](https://t.me/onBlockchain)
*   Netflix 讨论群:[https://t.me/netflixchina](https://t.me/netflixchina)
*   Netflix 讨论:[https://t.me/joinchat/C94vkUP2WbygEhA59U4mZA](https://t.me/joinchat/C94vkUP2WbygEhA59U4mZA)
*   gate.io 的小伙伴们:[https://t.me/gate_io](https://t.me/gate_io)
*   the speechless $$ apexidea:[https://t.me/thespeechless](https://t.me/thespeechless)
*   内涵段子:[https://t.me/duanzige](https://t.me/duanzige)
*   [ZH/EN] 摄影:[https://t.me/cnphotog](https://t.me/cnphotog)
*   加速吧小宝（koolshare merlin firmware）:[https://t.me/xbchat](https://t.me/xbchat)
*   软路由交流群:[https://t.me/ruanlu](https://t.me/ruanlu)
*   eSir PlayGround:[https://t.me/joinchat/JjxmyRZZXJWb74I-sCrryA](https://t.me/joinchat/JjxmyRZZXJWb74I-sCrryA)
*   机场联萌 - Linux&vps@SSpanel:[http://t.me/supermarket666](http://t.me/supermarket666)
*   阿里云交流群:[https://t.me/Balancer985](https://t.me/Balancer985)
*   微软云 (Azure) 交流群:[https://t.me/Balancer211](https://t.me/Balancer211)
*   谷歌云 (Gcp) 交流群:[https://t.me/Balancer166](https://t.me/Balancer166)
*   Vim 用户交流群:[http://t.me/vimhub](http://t.me/vimhub)
*   iOS 越狱讨论群:[https://t.me/iOS_Jailbreak](https://t.me/iOS_Jailbreak)
*   iOS 越狱交流群:[https://t.me/iOS_jailbreaking](https://t.me/iOS_jailbreaking)
*   自由世界之声:[https://t.me/TetgramC](https://t.me/TetgramC)
*   wikipedia-zh 中文維基百科聊天室:[https://t.me/wikipedia_zh_n](https://t.me/wikipedia_zh_n)
*   wikipedia-zh-help:[https://t.me/wikipedia_zh_help](https://t.me/wikipedia_zh_help)
*   wikipedia-zh-game:[https://t.me/wikipedia_zh_game](https://t.me/wikipedia_zh_game)
*   台大維基社:[https://t.me/ntuwpc](https://t.me/ntuwpc)
*   Vediotalk:[https://t.me/VedioTalkGroup](https://t.me/VedioTalkGroup)
*   利器 👨🏻‍💻👩‍💻 🧤:[https://t.me/fun_makers](https://t.me/fun_makers)
*   酷安闲聊群:[https://t.me/coolapkxianliao](https://t.me/coolapkxianliao)
*   酷安:[https://t.me/cool_apk](https://t.me/cool_apk)
*   Licenses Group 合租 美剧讨论 薅羊毛:[https://t.me/Licensess](https://t.me/Licensess)
*   [合租] Netflix Spotify office365 YouTube Hulu Surge 等音乐影视:[https://t.me/hezu1](https://t.me/hezu1)
*   品云合租:[https://t.me/PinYunHeZu](https://t.me/PinYunHeZu)
*   奈飞小铺:[https://t.me/joinchat/V2Qxg-u4XncM3F9m](https://t.me/joinchat/V2Qxg-u4XncM3F9m)
*   合租小车🚗:[https://t.me/TogetherHub](https://t.me/TogetherHub)
*   拼车小组:[https://t.me/PinCheGroup](https://t.me/PinCheGroup)
*   netflix spotify hulu 账号交流:[https://t.me/zxc1017yyfx](https://t.me/zxc1017yyfx)
*   Netflix/Spo/Hulu/HBO 低价体验车:[https://t.me/FreetrialStore](https://t.me/FreetrialStore)
*   Ben 先生的杂货铺:[https://t.me/joinchat/K1vTsBMebnPn7mLwR6KGmA](https://t.me/joinchat/K1vTsBMebnPn7mLwR6KGmA)
*   Freetrial.store:[https://t.me/FreetrialStore](https://t.me/FreetrialStore)
*   EhViewer・DEPRECATED・交流群:[https://t.me/ehviewer](https://t.me/ehviewer)
*   谷歌、微软云盘讨论群:[https://t.me/google_win](https://t.me/google_win)
*   VIA Official Group:[https://t.me/viatg](https://t.me/viatg)
*   Magisk 中文讨论群组:[https://t.me/magiskCNshare](https://t.me/magiskCNshare)
*   Spotify Addict Group:[https://t.me/spotifyaddict](https://t.me/spotifyaddict)
*   Spotify 使用者:[https://t.me/joinchat/DlW6BkAiT7ReIIADtANzYw](https://t.me/joinchat/DlW6BkAiT7ReIIADtANzYw)
*   奈菲影视 官方交流群:[https://t.me/joinchat/KmUaGRMWdO29JVd3wcCHCg](https://t.me/joinchat/KmUaGRMWdO29JVd3wcCHCg)
*   峰哥分享技术交流超级群:[https://t.me/fengsharegroup](https://t.me/fengsharegroup)
*   TG 技术党:[https://t.me/MRHXPJ](https://t.me/MRHXPJ)
*   Pi&N1 玩家交流群，专业:[https://t.me/PIN1Group](https://t.me/PIN1Group)
*   小声读书:[https://t.me/what_youread](https://t.me/what_youread)
*   ZBook，精品电子书:[https://t.me/ziyuanfengxiang59](https://t.me/ziyuanfengxiang59)
*   ReadFine 交流总群:[https://t.me/ReadfineChat](https://t.me/ReadfineChat)
*   读书分享:[https://t.me/dushufenxiang_chat](https://t.me/dushufenxiang_chat)
*   zread 读书会:[https://t.me/zread](https://t.me/zread)
*   Chinese Developers:[https://t.me/ChineseDevelopers](https://t.me/ChineseDevelopers)
*   BAT 大家庭:[https://t.me/china_net_group](https://t.me/china_net_group)
*   三人行中文群 (工作生活学习交流平台):[https://t.me/three001](https://t.me/three001)
*   流浪防区 /r/China_irl 官方群:[https://t.me/China_irl](https://t.me/China_irl)
*   主机贴士:[https://t.me/BWH1NET](https://t.me/BWH1NET)
*   二进制 /sudo:[https://t.me/huochesiji](https://t.me/huochesiji)
*   Google Voice 讨论组:[https://t.me/swatpc1](https://t.me/swatpc1)
*   专业 Linux / 运维 / 虚拟化讨论:[https://t.me/professionallinux](https://t.me/professionallinux)
*   酸奶 ssr2.0:[https://t.me/ssruSSR](https://t.me/ssruSSR)
*   趣・享:[https://t.me/peekfun](https://t.me/peekfun)
*   苹果旧版交流:[https://t.me/xinapp](https://t.me/xinapp)
*   Amazon 海淘购物交流群:[https://t.me/firstAmazon](https://t.me/firstAmazon)
*   Cloudflare 在中国:[https://t.me/CN_Cloudflare](https://t.me/CN_Cloudflare)
*   日本語学習 Japanese Study:[https://t.me/joinchat/BGDV_Qcq7MTcpiFkB2n7Fw](https://t.me/joinchat/BGDV_Qcq7MTcpiFkB2n7Fw)
*   ZUOLUOTV 专属交流群:[https://t.me/zuoluotv](https://t.me/zuoluotv)
*   Affyun.com:[https://t.me/pingcat](https://t.me/pingcat)
*   91yun.co 大海航行靠舵手:[https://t.me/im91yun](https://t.me/im91yun)
*   Leonn:[https://t.me/zhenggui](https://t.me/zhenggui)
*   古博 - VPS 仓交流群 / VPS 推荐实测:[https://t.me/guboorg](https://t.me/guboorg)
*   Technical Blog 技術博客:[https://t.me/Technical_Blog](https://t.me/Technical_Blog)
*   GigsGigsCloud.com 意见交流:[http://t.me/gigsgigscloudgroup](http://t.me/gigsgigscloudgroup)
*   微基主机讨论组 - 原 50KVM/50VZ:[https://t.me/network50_chat](https://t.me/network50_chat)
*   Nathosts 主机交流群:[https://t.me/nathosts](https://t.me/nathosts)
*   利器社群在 TG 上的分支:[http://t.me/fun_makers](http://t.me/fun_makers)
*   人人影视字幕文件:[http://t.me/yyets_subtitles](http://t.me/yyets_subtitles)
*   圆角水群:[https://t.me/UoVzCloud](https://t.me/UoVzCloud)
*   中文独立博客:[https://t.me/indieBlogs](https://t.me/indieBlogs)
*   黑苹果 osx86 项目中文讨论 / Hackintosh CHN Discussion:[https://t.me/osx86zh](https://t.me/osx86zh)
*   Chromebook CN:[https://t.me/chromebook_cn](https://t.me/chromebook_cn)
*   C 语言中文交流:[https://t.me/Clanguagezh](https://t.me/Clanguagezh)
*   C++ 中文交流:[https://t.me/cpluspluszh](https://t.me/cpluspluszh)
*   CSS 討論區:[https://t.me/csstw](https://t.me/csstw)
*   Haskell 中文交流:[https://t.me/haskellzh](https://t.me/haskellzh)
*   JavaScript 中文交流:[https://t.me/javascriptzh](https://t.me/javascriptzh)
*   Julia 编程语言交流:[https://t.me/julialangzh](https://t.me/julialangzh)
*   Perl 中文交流:[https://t.me/perlzh](https://t.me/perlzh)
*   Python:[https://t.me/Python](https://t.me/Python)
*   Python 中文交流:[https://t.me/pythonzh](https://t.me/pythonzh)
*   Go:[https://t.me/GolangCN](https://t.me/GolangCN)
*   R 语言中文交流:[https://t.me/rprojectzh](https://t.me/rprojectzh)
*   Scala 中文群组:[https://t.me/scala_zh](https://t.me/scala_zh)
*   TypeScript 中文交流:[https://t.me/typescriptzh](https://t.me/typescriptzh)
*   Kali / BlackArch Linux 中文交流:[https://t.me/hackerzh](https://t.me/hackerzh)
*   CentOS 中文:[https://t.me/centoszh](https://t.me/centoszh)
*   Ubuntu 中文:[https://t.me/ubuntuzh](https://t.me/ubuntuzh)
*   Java/Android 开发交流:[https://t.me/java_android_dev](https://t.me/java_android_dev)
*   大数据杂谈:[https://t.me/bigdatazh](https://t.me/bigdatazh)
*   Frontend 前端中文技术交流:[https://t.me/frontend_talk](https://t.me/frontend_talk)
*   Hexo 博客交流:[https://t.me/hexozh](https://t.me/hexozh)
*   Hugo 博客交流:[https://t.me/hugoblog](https://t.me/hugoblog)
*   ZeroNet 中文交流:[https://t.me/zeronetzh](https://t.me/zeronetzh)
*   体育爱好者 / 足球 / 篮球 / NBA/CBA 交流:[https://t.me/tiyu365](https://t.me/tiyu365)
*   Wallpapers 壁纸:[https://t.me/G_Wallpapers](https://t.me/G_Wallpapers)
*   SM.MS 图床粉丝群:[https://t.me/smms_images](https://t.me/smms_images)
*   ios 黑科技交流群:[https://t.me/ioshkj007](https://t.me/ioshkj007)
*   HN 中文社区:[https://t.me/hn_china](https://t.me/hn_china)
*   树莓派:[https://t.me/shumeipai](https://t.me/shumeipai)
*   中英語言学习:[https://t.me/LinguisticAcademy](https://t.me/LinguisticAcademy)
*   TechCrunch 中文讨论组:[https://t.me/tcchinese](https://t.me/tcchinese)
*   🀄️ Fedora 中文用户组:[https://t.me/fedorazh](https://t.me/fedorazh)
*   PS4:[https://t.me/ps4cn2](https://t.me/ps4cn2)
*   Tg 云音乐:[https://t.me/Tgsongs](https://t.me/Tgsongs)
*   Handshake 中文社区:[https://t.me/handshake_cn](https://t.me/handshake_cn)
*   第二现场:[https://t.me/dearlive](https://t.me/dearlive)
*   科技聚会:[https://t.me/pixelcn](https://t.me/pixelcn)
*   翼起乐:[https://t.me/YiQiLe](https://t.me/YiQiLe)
*   PanoanDrive (离线下载自动转存 Google Drive):[https://t.me/PanoanDriveBasic](https://t.me/PanoanDriveBasic)
*   Anytype community:[https://t.me/anytype](https://t.me/anytype)
*   今日热榜:[https://t.me/joinchat/IL6n4w9xiRMvHaU1YpVFog](https://t.me/joinchat/IL6n4w9xiRMvHaU1YpVFog)
*   西西书屋 精校电子书:[https://t.me/xixishuwu](https://t.me/xixishuwu)
*   读者・争鸣:[https://t.me/duzhe](https://t.me/duzhe)
*   Life & Knowledge.:[https://t.me/LifeAndKnowledge](https://t.me/LifeAndKnowledge)
*   [CN]Flutter Dev:[https://t.me/FlutterCN](https://t.me/FlutterCN)
*   Infuse 官方中文群:[https://t.me/infusepro6](https://t.me/infusepro6)
*   台灣蘋果同好交流群:[https://t.me/TaiwanAppleFans](https://t.me/TaiwanAppleFans)
*   日本旅遊同好交流群:[https://t.me/JP_Travel](https://t.me/JP_Travel)
*   高清影音数码折腾群:[https://t.me/TalkUHD](https://t.me/TalkUHD)
*   Bot 开发者交流群:[https://t.me/bot_dev_group](https://t.me/bot_dev_group)
*   XDA Labs:[https://t.me/xda_feed](https://t.me/xda_feed)
*   码力全开 Friends:[https://t.me/forcecoder](https://t.me/forcecoder)
*   奈飞 Pro - Netflix 奈飞合租 / 拼车:[https://t.me/naifei_pro](https://t.me/naifei_pro)
*   中文翻译机器人反馈群:[https://t.me/fanyi_group](https://t.me/fanyi_group)
*   SaltyLeo 的博客讨论组:[https://t.me/SaltyLeo_blog](https://t.me/SaltyLeo_blog)
*   OpenWrt Discuss CTCGFW’s Group:[https://t.me/ctcgfw_openwrt_discuss](https://t.me/ctcgfw_openwrt_discuss)
*   anki 交流群:[https://t.me/anki_app](https://t.me/anki_app)
*   PayPal 交流群:[https://t.me/paypal_us](https://t.me/paypal_us)
*   大佬装逼群:[https://t.me/xddos11](https://t.me/xddos11)
*   腾讯云☆阿里云🅥:[https://t.me/TencentAliyun](https://t.me/TencentAliyun)
*   MugglePay 麻瓜宝用户群:[https://t.me/mugglepay](https://t.me/mugglepay)
*   Linmi 简日志:[https://t.me/cmemo](https://t.me/cmemo)
*   硬核英语 / Hardcore English:[https://t.me/hardcoreng](https://t.me/hardcoreng)
*   学习捷径:[https://t.me/officelearner](https://t.me/officelearner)
*   8 度科技:[https://t.me/abc999222](https://t.me/abc999222)
*   Windows/Mac/Linux 交流群:[https://t.me/zhucaidan](https://t.me/zhucaidan)
*   叶清风的小店的讨论组:[https://t.me/OwO_G](https://t.me/OwO_G)
*   期货与期权 Derivatives:[https://t.me/CNderivatives](https://t.me/CNderivatives)
*   Nathosts 主机交流群:[https://t.me/nathosts](https://t.me/nathosts)
*   键盘交流群:[https://t.me/keyboard_cn](https://t.me/keyboard_cn)
*   闲蛋面板🥚交流群:[https://t.me/xdzzmb](https://t.me/xdzzmb)
*   加密货币爱好者:[https://t.me/twittercryptofans](https://t.me/twittercryptofans)

###### 播客
*   一天世界:[https://t.me/ipn_yitianshijie](https://t.me/ipn_yitianshijie)
*   ○△□（不鳥萬通讯）:[https://t.me/igiveafuck](https://t.me/igiveafuck)
*   灭茶苦茶 听众群:[https://t.me/ipn_miechakucha](https://t.me/ipn_miechakucha)
*   《内核恐慌》听众群:[https://t.me/pan_icu](https://t.me/pan_icu)
*   博物志 听众群:[https://t.me/museelogue](https://t.me/museelogue)
*   太医来了 听众群:[https://t.me/taiyilaile](https://t.me/taiyilaile)
*   味之道 听众群:[https://t.me/joinchat/At5ANzuy5JM9yhPrmuGrcQ](https://t.me/joinchat/At5ANzuy5JM9yhPrmuGrcQ)
*   时尚怪物 听众群:[https://t.me/ipn_fashionmonster](https://t.me/ipn_fashionmonster)
*   科技聚变 TechFusion 听众群:[https://t.me/TechFusionChat](https://t.me/TechFusionChat)
*   播客大家谈:[https://t.me/bokecn](https://t.me/bokecn)
*   「得意忘形」听众群:[https://t.me/joinchat/Bx8JqQ33oVCrKSul-cHJGQ](https://t.me/joinchat/Bx8JqQ33oVCrKSul-cHJGQ)

###### Telegram

*   Durov’s Chat:[https://t.me/durovschat](https://t.me/durovschat)
*   官方翻译支持群 English:[https://t.me/translation_en](https://t.me/translation_en)
*   官方翻译支持群 简体中文 (聪聪):[https://t.me/translation_zhcncc](https://t.me/translation_zhcncc)
*   官方翻译支持群 简体中文:[https://t.me/translation_zh_hans](https://t.me/translation_zh_hans)
*   官方翻译支持群 简体中文 (@zh_CN 版):[https://t.me/translation_classic_zh_cn](https://t.me/translation_classic_zh_cn)
*   官方翻译支持群 简体中文 (langCN):[https://t.me/translation_zhlangcn](https://t.me/translation_zhlangcn)
*   官方翻译支持群 瓜体中文:[https://t.me/translation_duang_zh_hans](https://t.me/translation_duang_zh_hans)
*   官方翻译支持群 繁体中文 (香港):[https://t.me/translation_zh_hant](https://t.me/translation_zh_hant)
*   官方翻译支持群 繁体中文 (台湾):[https://t.me/translation_taiwan](https://t.me/translation_taiwan)
*   官方翻译支持群 喵体中文 （ @MiaoCN ）:[https://t.me/translation_meowcn](https://t.me/translation_meowcn)
*   官方翻译支持群 郭桓桓的繁體中文語言包:[https://t.me/translation_zhong_taiwan_traditional](https://t.me/translation_zhong_taiwan_traditional)
*   官方翻译支持群 文言:[https://t.me/translation_chinese_ancient](https://t.me/translation_chinese_ancient)
*   TG 简中交流（水）群:[https://t.me/cnpub](https://t.me/cnpub)
*   Telegram 討論區:[https://t.me/PublicGroupForzh](https://t.me/PublicGroupForzh)
*   Telegram 新手帮助:[https://t.me/newbie_chat](https://t.me/newbie_chat)
*   Telegram Contests:[https://t.me/contests](https://t.me/contests)
*   Конкурсы Telegram:[https://t.me/contests_ru](https://t.me/contests_ru)
*   Telegram iOS Beta Testing:[https://t.me/tgiostests](https://t.me/tgiostests)
*   Telegram iOS Talk:[https://t.me/TelegramiOStalk](https://t.me/TelegramiOStalk)
*   Telegram Android Talk:[https://t.me/TelegramAndroidTalk](https://t.me/TelegramAndroidTalk)
*   Telegram Alpha Talk:[https://t.me/tgalphachat](https://t.me/tgalphachat)
*   TDLib chat:[https://t.me/tdlibchat](https://t.me/tdlibchat)
*   Telegram X Android:[https://t.me/tgandroidtests](https://t.me/tgandroidtests)
*   Telegram macOS:[https://t.me/macswift](https://t.me/macswift)
*   Telegram macOS Talk:[https://t.me/TelegramMacOsTalk](https://t.me/TelegramMacOsTalk)
*   Telegram Desktop Talk:[https://t.me/TelegramDesktopTalk](https://t.me/TelegramDesktopTalk)
*   Telegram Windows Phone Talk:[https://t.me/TelegramWPtalk](https://t.me/TelegramWPtalk)
*   Telegram Bot Talk:[https://t.me/BotTalk](https://t.me/BotTalk)
*   Telegram Party:[https://t.me/PublicTestGroup](https://t.me/PublicTestGroup)
*   Telegram iOS Themes:[https://t.me/IOSTelegramThemes](https://t.me/IOSTelegramThemes)
*   Telegram Android Themes:[https://t.me/AndroidThemesGroup](https://t.me/AndroidThemesGroup)
*   Telegram Desktop Themes:[https://t.me/TelegramThemes](https://t.me/TelegramThemes)
*   Telegram X: Themes:[http://t.me/tgx_perfection](http://t.me/tgx_perfection)
*   分享好看的 Telegram 主题:[https://t.me/beautifultgtheme](https://t.me/beautifultgtheme)
*   分享好看的 Telegram 主题:[https://t.me/MeowThemes](https://t.me/MeowThemes)
*   Telegram Beta Chat:[https://t.me/tgbetachat](https://t.me/tgbetachat)
*   Tentang Telegram:[https://t.me/tentangtelegram](https://t.me/tentangtelegram)
*   Snowball Fight:[https://t.me/SnowballFight](https://t.me/SnowballFight)
*   Tentang Telegram:[https://t.me/tentangtelegram](https://t.me/tentangtelegram)
*   Instant View Platform Chat:[https://t.me/IVpublic](https://t.me/IVpublic)
*   Telegram 新手問答區:[https://t.me/TGQNA](https://t.me/TGQNA)
*   Telegram 新手频道讨论组:[https://t.me/newbie_tele_discussion](https://t.me/newbie_tele_discussion)
*   電報群推廣:[https://t.me/joinchat/FAir4j15AV8Q_x5zzoc8yw](https://t.me/joinchat/FAir4j15AV8Q_x5zzoc8yw)
*   Plus Messenger Support:[https://t.me/plusmsgrchat](https://t.me/plusmsgrchat)
*   Plus Messenger Chat:[https://t.me/offTopicPlusChat](https://t.me/offTopicPlusChat)
*   Plus Messenger 中文討論區:[https://t.me/plusfgc](https://t.me/plusfgc)
*   Kotatogram:[https://t.me/kotatogram](https://t.me/kotatogram)
*   Unigram Insiders:[https://t.me/unigraminsiders](https://t.me/unigraminsiders)
*   KeralaGram:[https://t.me/keralagram](https://t.me/keralagram)
*   64Gram:[https://t.me/tg_x64](https://t.me/tg_x64)
*   telegram.Bot:[https://t.me/pythontelegrambotgroup](https://t.me/pythontelegrambotgroup)

###### 地区群

*   深圳:[https://t.me/shenzhenbot?start=join](https://t.me/shenzhenbot?start=join)
*   深圳:[https://t.me/shenzhentg](https://t.me/shenzhentg)
*   北京:[https://t.me/beijingz](https://t.me/beijingz)
*   广州:[https://t.me/GuangzhouIT](https://t.me/GuangzhouIT)
*   四川:[https://t.me/civhuanglaoxiao](https://t.me/civhuanglaoxiao)
*   川渝:[https://t.me/chongqing_sichuang](https://t.me/chongqing_sichuang)
*   西安:[https://t.me/XianCity](https://t.me/XianCity)
*   南宁:[https://t.me/NanNingTG](https://t.me/NanNingTG)
*   滕州:[https://t.me/tengzhou](https://t.me/tengzhou)
*   烟台:[https://t.me/yantaiinfo](https://t.me/yantaiinfo)
*   湖南:[https://t.me/hunantg](https://t.me/hunantg)
*   济南:[https://t.me/jinan_tg](https://t.me/jinan_tg)
*   郑州:[https://t.me/zhengzhoutg](https://t.me/zhengzhoutg)
*   西安:[https://t.me/joinchat/FY1SJkRF6ubEQzU-3Mq3cw](https://t.me/joinchat/FY1SJkRF6ubEQzU-3Mq3cw)
*   河南郑州:[https://t.me/hnzzs](https://t.me/hnzzs)
*   河南周口:[https://t.me/zhoukou](https://t.me/zhoukou)
*   杭州电报群|杭州茶馆:[https://t.me/+bJkN6Cz7WIQ5YjQ9](https://t.me/+bJkN6Cz7WIQ5YjQ9)

###### 其他

*   Coder Offtopic 中文群:[https://t.me/coder_ot](https://t.me/coder_ot)
*   BoastTG:[https://t.me/BoastTG](https://t.me/BoastTG)
*   Steam&PlayStation&Xbox&Switch:[https://t.me/ps4cn2](https://t.me/ps4cn2)
*   KoolProxy:[https://t.me/joinchat/AAAAAD-tO7GPvfOU131_vg](https://t.me/joinchat/AAAAAD-tO7GPvfOU131_vg)
*   图话天下:[https://t.me/joinchat/Ap7Q_zvEXX48wixHbtg79A](https://t.me/joinchat/Ap7Q_zvEXX48wixHbtg79A)
*   烧饼博客粉丝群:[https://t.me/sbfans](https://t.me/sbfans)
*   圍觀設計師現場:[https://t.me/lookingforqoli](https://t.me/lookingforqoli)
*   Official Counterparty Chat:[https://t.me/Counterparty_XCP](https://t.me/Counterparty_XCP)
*   Casual ENGLISH Chat:[https://t.me/joinchat/AAAAAEBz8Owuzgri6kB2UA](https://t.me/joinchat/AAAAAEBz8Owuzgri6kB2UA)
*   愚民小鎮:[https://t.me/twWolf](https://t.me/twWolf)
*   PDA 的 Discovery 版块:[https://t.me/discoverys](https://t.me/discoverys)
*   骇客邦:[https://t.me/hihackers](https://t.me/hihackers)
*   S&D 两位先生:[https://t.me/Science_Democracy](https://t.me/Science_Democracy)
*   欧美生活影视音乐圈 Europe America:[https://t.me/AJSCIEAA](https://t.me/AJSCIEAA)
*   Sit and Date:[https://t.me/SitandRelaxGroup](https://t.me/SitandRelaxGroup)
*   ACGN☆Taiwan:[http://t.me/TaiwanAnime](http://t.me/TaiwanAnime)
*   内涵段子之闲聊群:[https://t.me/OverseasChinese](https://t.me/OverseasChinese)
*   上帝是女孩:[https://t.me/Godaregirls](https://t.me/Godaregirls)
*   Telegram 狼人杀群:[https://t.me/langrensha888](https://t.me/langrensha888)
*   RSS 屋:[https://t.me/joinchat/HiIOAxV7g9JwNuLuThUsyQ](https://t.me/joinchat/HiIOAxV7g9JwNuLuThUsyQ)
*   电报唱吧:[https://t.me/changba_tg](https://t.me/changba_tg)
*   SPhard 交流群:[https://t.me/sphard](https://t.me/sphard)
*   璃颜 & 红尘，伊人笑:[https://t.me/liyanhongchen](https://t.me/liyanhongchen)
*   搞笑视频:[https://t.me/joinchat/AAAAAFe-j4P9-B1VgdAmJw](https://t.me/joinchat/AAAAAFe-j4P9-B1VgdAmJw)
*   Hanan’s Group:[https://t.me/hanhans2](https://t.me/hanhans2)
*   创造者日报:[https://t.me/creatorsdaily](https://t.me/creatorsdaily)
*   Tg 唱吧总站:[https://t.me/changba_tg](https://t.me/changba_tg)
*   Zapro・杂铺 HAPPY:[https://t.me/tmioeTG](https://t.me/tmioeTG)
*   Faangbbs 北美程序员大群:[https://t.me/faangbbs](https://t.me/faangbbs)
*   Count To 1 Million:[https://t.me/CountToOneMillion](https://t.me/CountToOneMillion)
*   No U:[https://t.me/NoUGroup](https://t.me/NoUGroup)
*   APPDO 数字生活指南:[https://t.me/appdododo](https://t.me/appdododo)
*   FriendChCodeList:[https://t.me/FriendChCodeList](https://t.me/FriendChCodeList)
*   oooooohmygosh & friends:[https://t.me/omgfriends](https://t.me/omgfriends)
*   No.1 Manila_服务器_优秀的服务器_服务器托管租用_:[https://t.me/PHmanila](https://t.me/PHmanila)
*   Leetcode 刷题:[https://t.me/leetcode_discuss](https://t.me/leetcode_discuss)
*   LeetCode + Interview Prep 2021:[https://t.me/leetcode_discussion](https://t.me/leetcode_discussion)
*   验证码平台:[https://t.me/jiema_USA](https://t.me/jiema_USA)
*   验证码平台:[https://t.me/jiemapingtai2](https://t.me/jiemapingtai2)
*   沙雕根据地:[https://t.me/shadiaoo](https://t.me/shadiaoo)
*   ACG 萌:[https://t.me/acg_moe](https://t.me/acg_moe)
*   WSB 华尔街中文社区:[https://t.me/WSBetsZH](https://t.me/WSBetsZH)
*   华尔街日报 RSS:[https://t.me/wsj_rss](https://t.me/wsj_rss)
*   Satoshi Street Bets 中本街社区:[https://t.me/SatoshiStreetBetsZH](https://t.me/SatoshiStreetBetsZH)
*   tsuPro Talk:[https://t.me/tsuPorn](https://t.me/tsuPorn)
*   想尽办法看电视:[https://t.me/joinchat/MgUQ3B1apkzq3sqVzTFP0A](https://t.me/joinchat/MgUQ3B1apkzq3sqVzTFP0A)
*   一起充电群:[https://t.me/letsbuycharger](https://t.me/letsbuycharger)

##### 频道 Channel

*   Durov’s Channel（Telegram 创始人兼 CEO 的频道）:[https://t.me/durov](https://t.me/durov)
*   Telegram 官方诈骗举报:[https://t.me/notoscam](https://t.me/notoscam)
*   Telegram-zh_CN Project:[https://t.me/zh_CN](https://t.me/zh_CN)
*   Telegram 简体中文:[https://t.me/tele_zh_cn](https://t.me/tele_zh_cn)
*   Telegram 繁体中文:[https://t.me/Tele_zh_TW](https://t.me/Tele_zh_TW)
*   Telegram News:[https://t.me/telegram](https://t.me/telegram)
*   Telegram Tips:[https://t.me/TelegramTips](https://t.me/TelegramTips)
*   Telegram Features:[https://t.me/features](https://t.me/features)
*   Telegram Geeks:[https://t.me/geekschannel](https://t.me/geekschannel)
*   Telegram Info English:[https://t.me/tginfoen](https://t.me/tginfoen)
*   Telegram Info:[https://t.me/tginfo](https://t.me/tginfo)
*   Telegram Apps:[https://t.me/tgfiles](https://t.me/tgfiles)
*   Telegram APKs for Android:[https://t.me/TAndroidAPK](https://t.me/TAndroidAPK)
*   Telegram for macOS Updates:[https://t.me/macos_stable_updates_files](https://t.me/macos_stable_updates_files)
*   Telegram Stable Releases:[https://t.me/tgstable](https://t.me/tgstable)
*   Telegram Beta:[https://t.me/tgbeta](https://t.me/tgbeta)
*   Telegram X:[https://t.me/tgx_android](https://t.me/tgx_android)
*   Telegram Beta Blog:[https://t.me/tgrambeta](https://t.me/tgrambeta)
*   Telegram Designers:[https://t.me/designers](https://t.me/designers)
*   Telegram Contests:[https://t.me/contest](https://t.me/contest)
*   Telegram Memes:[https://t.me/MemesTelegram](https://t.me/MemesTelegram)
*   Instant View Contest News:[https://t.me/IVcontest](https://t.me/IVcontest)
*   Telegram BotNews:[https://t.me/BotNews](https://t.me/BotNews)
*   Katalog Telegram:[https://t.me/katalogtelegram](https://t.me/katalogtelegram)
*   Telegram iOS Beta Slots:[https://t.me/tgslots](https://t.me/tgslots)
*   Telegram Blog Secrets:[https://t.me/tgblog_secrets](https://t.me/tgblog_secrets)
*   Telegram Censorship Report:[https://t.me/TCReport](https://t.me/TCReport)
*   durov_russia:[https://t.me/durov_russia](https://t.me/durov_russia)
*   tgx_android_translate:[https://t.me/tgx_android_translate](https://t.me/tgx_android_translate)
*   desktop:[https://t.me/desktop](https://t.me/desktop)
*   AptitudeTestContest:[https://t.me/AptitudeTestContest](https://t.me/AptitudeTestContest)
*   IsisWatch:[https://t.me/IsisWatch](https://t.me/IsisWatch)
*   stopCA:[https://t.me/stopCA](https://t.me/stopCA)
*   username:[https://t.me/username](https://t.me/username)
*   TelegramIT:[https://t.me/TelegramIT](https://t.me/TelegramIT)
*   TelegramES:[https://t.me/TelegramES](https://t.me/TelegramES)
*   TelegramDE:[https://t.me/TelegramDE](https://t.me/TelegramDE)
*   TelegramArabia:[https://t.me/TelegramArabia](https://t.me/TelegramArabia)
*   TelegramNL:[https://t.me/TelegramNL](https://t.me/TelegramNL)
*   TelegramIndonesia:[https://t.me/TelegramIndonesia](https://t.me/TelegramIndonesia)
*   TelegramBR:[https://t.me/TelegramBR](https://t.me/TelegramBR)
*   DiscussThis:[https://t.me/DiscussThis](https://t.me/DiscussThis)
*   telegramtipsit:[https://t.me/telegramtipsit](https://t.me/telegramtipsit)
*   telegramtipsbr:[https://t.me/telegramtipsbr](https://t.me/telegramtipsbr)
*   telegramtipsAR:[https://t.me/telegramtipsAR](https://t.me/telegramtipsAR)
*   telegramtipsES:[https://t.me/telegramtipsES](https://t.me/telegramtipsES)
*   telegramtipsID:[https://t.me/telegramtipsID](https://t.me/telegramtipsID)
*   connectivity_test:[https://t.me/connectivity_test](https://t.me/connectivity_test)
*   topanimated:[https://t.me/topanimated](https://t.me/topanimated)
*   videomessages:[https://t.me/videomessages](https://t.me/videomessages)
*   Transparency:[https://t.me/Transparency](https://t.me/Transparency)
*   virus:[https://t.me/virus](https://t.me/virus)
*   macos_stable_updates_files:[https://t.me/macos_stable_updates_files](https://t.me/macos_stable_updates_files)
*   Telegram 新手指南:[https://t.me/newbie_guide](https://t.me/newbie_guide)
*   Telegram 种植园:[https://t.me/TelePlanting](https://t.me/TelePlanting)
*   Telegram 新手入口:[https://t.me/StartTG](https://t.me/StartTG)
*   Desktop Themes Channel:[https://t.me/themes](https://t.me/themes)
*   Telegram Desktop Themes:[https://t.me/desktopThemes](https://t.me/desktopThemes)
*   Telegram Themes:[https://t.me/themechannel](https://t.me/themechannel)
*   Telegram Themes:[https://t.me/themeschannel](https://t.me/themeschannel)
*   rThemes:[https://t.me/rThemes](https://t.me/rThemes)
*   ThemeTelegram X:[https://t.me/ThemeTelegram_X](https://t.me/ThemeTelegram_X)
*   Android Themes Channel:[https://t.me/AndroidThemes](https://t.me/AndroidThemes)
*   Telegram Theme By Shana:[https://t.me/ShanaThemes](https://t.me/ShanaThemes)
*   Cancer Themes:[https://t.me/cancerthemes](https://t.me/cancerthemes)
*   VANILLA TELEGRAM THEMES:[https://t.me/VanillaTG](https://t.me/VanillaTG)
*   Telegram Stickers:[https://t.me/TgSticker](https://t.me/TgSticker)
*   Telegram 新手频道:[https://t.me/newbie_tele](https://t.me/newbie_tele)
*   Telegram 文言翻譯之官方頻道:[https://t.me/classical_chinese](https://t.me/classical_chinese)
*   電報群組廣播:[https://t.me/FOCUSTELEGRAMGROUPLINK](https://t.me/FOCUSTELEGRAMGROUPLINK)
*   電報新群推送:[https://t.me/linkpush](https://t.me/linkpush)
*   tg 机器人推荐:[https://t.me/tgbotlist](https://t.me/tgbotlist)
*   Telegreat Project:[https://t.me/Telegreat](https://t.me/Telegreat)
*   Telegram Passport:[https://t.me/TelegramPassport](https://t.me/TelegramPassport)
*   Plus Messenger official:[https://t.me/plusmsgr](https://t.me/plusmsgr)
*   KeralaGram [Official]®:[https://t.me/KeralaGramChannel](https://t.me/KeralaGramChannel)
*   Challegram:[https://t.me/Challegram](https://t.me/Challegram)
*   X Plus Channel:[https://t.me/XPlus_Channel](https://t.me/XPlus_Channel)
*   Nicegram:[https://t.me/nicegramapp](https://t.me/nicegramapp)
*   Nicegram Dev:[https://t.me/nicegramdev](https://t.me/nicegramdev)
*   捷报 News:[https://t.me/JieBaoNews](https://t.me/JieBaoNews)
*   PagerMaid-Modify Update:[https://t.me/PagerMaid_Modify](https://t.me/PagerMaid_Modify)

###### 翻墙

*   毒药机场测速 SS/SSR:[https://t.me/DuyaoSS](https://t.me/DuyaoSS)
*   V1 Blog 科技 生活 SpeedTest 主机评测:[https://t.me/V1_BLOG](https://t.me/V1_BLOG)
*   機場海外測速中心:[https://t.me/BlacklotusChannel](https://t.me/BlacklotusChannel)
*   品云☁️测速:[https://t.me/PinYunPs](https://t.me/PinYunPs)
*   ss，ssr，v2ray 机场测速:[https://t.me/askahh](https://t.me/askahh)
*   前女友们用过的机场:[https://t.me/gebaopiCloud](https://t.me/gebaopiCloud)
*   全球互联网测速中心:[https://t.me/speedcentre](https://t.me/speedcentre)
*   全球互联网节点中心:[https://t.me/sharecentre](https://t.me/sharecentre)
*   机场 ☁️ 测速:[https://t.me/yunspeedtest](https://t.me/yunspeedtest)
*   跑路公告板:[https://t.me/Paolutongzhi](https://t.me/Paolutongzhi)
*   秋水逸冰的个人频道:[https://t.me/qiushuiyibing](https://t.me/qiushuiyibing)
*   Surge 开发者的频道:[https://t.me/yachme](https://t.me/yachme)
*   Surge News:[https://t.me/surgenews](https://t.me/surgenews)
*   Shadowrocket News:[https://t.me/ShadowrocketNews](https://t.me/ShadowrocketNews)
*   Quantumult News:[https://t.me/QuanXNews](https://t.me/QuanXNews)
*   Qure for Quantumult X 图标:[https://t.me/QureIconSet](https://t.me/QureIconSet)
*   mini 图标包 for Quantumult X:[https://t.me/Orzmini](https://t.me/Orzmini)
*   PVSZ for QuanX:[https://t.me/PVSZforQuanX](https://t.me/PVSZforQuanX)
*   QuantumultX & Surge 脚本收集:[https://t.me/NobyDa](https://t.me/NobyDa)
*   Quantumult X JS 收集分享:[https://t.me/QuanXJS](https://t.me/QuanXJS)
*   Quantumult X 功能教学:[https://t.me/HellCellZC123](https://t.me/HellCellZC123)
*   QuantumultX 教程 & API & 解析器 更新通知频道:[https://t.me/QuanX_API](https://t.me/QuanX_API)
*   Chavy Scripts:[https://t.me/chavyscripts](https://t.me/chavyscripts)
*   zZPiglet:[https://t.me/zZPiglet](https://t.me/zZPiglet)
*   Project X Channel:[https://t.me/projectXtls](https://t.me/projectXtls)
*   W37° 大飛频道:[https://t.me/w37fhy](https://t.me/w37fhy)
*   DivineEngine:[https://t.me/DivineEngine](https://t.me/DivineEngine)
*   Cool Scripts:[https://t.me/cool_scripts](https://t.me/cool_scripts)
*   TG 规则脚本信息分享器:[https://t.me/MRHXPJGG](https://t.me/MRHXPJGG)
*   Tempest TCN(rixCloud):[https://t.me/TempestApp](https://t.me/TempestApp)
*   Trojan Qt5 News:[https://t.me/TrojanQt5News](https://t.me/TrojanQt5News)
*   ServerCat 主机喵:[https://t.me/servercat](https://t.me/servercat)
*   Surfboard News:[https://t.me/surfboardnews](https://t.me/surfboardnews)
*   魅影极速官方频道:[https://t.me/myjstw](https://t.me/myjstw)
*   魅影极速轻量站 ARK 频道:[https://t.me/arktochannel](https://t.me/arktochannel)
*   Fndroid 的日常 (Clash for Windows):[https://t.me/fndroid_news](https://t.me/fndroid_news)
*   Clash.NET 公告:[https://t.me/ClashDotNetFrameworkAnncmnt](https://t.me/ClashDotNetFrameworkAnncmnt)
*   Clash.Mini 公告频道:[https://t.me/ClashMiniNo1](https://t.me/ClashMiniNo1)
*   ClashR News:[https://t.me/ClashR_News](https://t.me/ClashR_News)
*   Clash (R) for Windows 公告板:[https://t.me/ClashR_for_Windows_Channel](https://t.me/ClashR_for_Windows_Channel)
*   ACL4SSR:[https://t.me/ACL4SSR](https://t.me/ACL4SSR)
*   Stick Rules:[https://t.me/usestick](https://t.me/usestick)
*   Free Telegram proxy:[https://t.me/proxyme](https://t.me/proxyme)
*   vAgent 官方福利资源发布频道:[https://t.me/everythingjustbegin](https://t.me/everythingjustbegin)
*   ss panel v3 mod 魔改修改版 News:[https://t.me/sspanel_Uim](https://t.me/sspanel_Uim)
*   BosLife:[https://t.me/boslifenews](https://t.me/boslifenews)
*   SubConverter 更新频道:[https://t.me/subconverter](https://t.me/subconverter)
*   VPN 测评 - 各类 VPN 相关资讯 + 真实测评:[https://t.me/VPNceping](https://t.me/VPNceping)
*   火箭空间站 (TG 代理):[https://t.me/Rocketcool](https://t.me/Rocketcool)
*   elecV2:[https://t.me/elecV2](https://t.me/elecV2)
*   科学上网与机场观察:[https://t.me/jichangtj](https://t.me/jichangtj)
*   YtFlow β:[https://t.me/YtFlowChannel](https://t.me/YtFlowChannel)
*   MerlinClash 猫咪爬梯:[https://t.me/merlinclashcat](https://t.me/merlinclashcat)
*   中信加速器 VPN 官方频道:[https://t.me/zxfast_channel](https://t.me/zxfast_channel)
*   黑科技 TG 代理:[https://t.me/iPoject](https://t.me/iPoject)

###### 软件

*   App 限免精选:[https://t.me/appfans](https://t.me/appfans)
*   iOS Releases:[https://t.me/iOSUpdates](https://t.me/iOSUpdates)
*   限時免費 LimitFree:[https://t.me/limitfree](https://t.me/limitfree)
*   App 限免 & TestFlight & 资讯聚合:[https://t.me/Appcn](https://t.me/Appcn)
*   Appinn Feed:[https://t.me/appinnfeed](https://t.me/appinnfeed)
*   Google Play Public:[https://t.me/GooglePlayPublic](https://t.me/GooglePlayPublic)
*   Snipaste:[https://t.me/snipaste](https://t.me/snipaste)
*   GitHub Trending:[https://t.me/githubtrending](https://t.me/githubtrending)
*   python-telegram-bot:[https://t.me/pythontelegrambotchannel](https://t.me/pythontelegrambotchannel)
*   简悦 - SimpRead:[https://t.me/simpread](https://t.me/simpread)
*   Vivaldi Browser:[https://t.me/vivaldibrowser](https://t.me/vivaldibrowser)
*   Z-Turns:[https://t.me/Z_Turns](https://t.me/Z_Turns)
*   Pythonista 3 脚本通知频道:[https://t.me/pythonista3jiaoben](https://t.me/pythonista3jiaoben)
*   Google Play 限免信息:[https://t.me/playsales](https://t.me/playsales)
*   ShortcutsCN 捷径社区:[https://t.me/ShortcutsCN](https://t.me/ShortcutsCN)
*   软件技术资源共享:[https://t.me/SharedResources](https://t.me/SharedResources)
*   TelePlus - 免翻牆電報:[https://t.me/TelePlus_Channel](https://t.me/TelePlus_Channel)
*   TestFlight:[https://t.me/TestFlightX](https://t.me/TestFlightX)
*   Unigram News:[https://t.me/unigram](https://t.me/unigram)
*   Unigram Appx:[https://t.me/unigramappx](https://t.me/unigramappx)
*   tg 生态观察:[https://t.me/tgsucks](https://t.me/tgsucks)
*   TGgeek TG 极客:[https://t.me/TGgeek](https://t.me/TGgeek)
*   老司机必备工具箱:[https://t.me/theguideoftelegram](https://t.me/theguideoftelegram)
*   闲置软路由信息发布:[https://t.me/supermarket66](https://t.me/supermarket66)
*   谷歌云 (GCP) 供需对接市场:[https://t.me/supermarket999](https://t.me/supermarket999)
*   AdGuard:[https://t.me/adguarden](https://t.me/adguarden)
*   AdGuard 消息:[https://t.me/AdGuardcn](https://t.me/AdGuardcn)
*   Adguard News:[https://t.me/AdguardNews](https://t.me/AdguardNews)
*   Office Tool Channel:[https://t.me/otp_channel](https://t.me/otp_channel)
*   「Meeta」share:[https://t.me/meetashare](https://t.me/meetashare)
*   App Store 游戏推荐:[http://t.me/AppStore_Games](http://t.me/AppStore_Games)
*   Pi&N1 交流群新频道:[https://t.me/NewPiN1Channel](https://t.me/NewPiN1Channel)
*   笔记软件交流讨论 - 频道:[https://t.me/joinchat/AAAAAFPA6feibNtwoeiZcw](https://t.me/joinchat/AAAAAFPA6feibNtwoeiZcw)
*   App Store、Google Play 礼品卡:[https://t.me/iTunesGiftNews](https://t.me/iTunesGiftNews)
*   Nekogram APKs:[https://t.me/NekogramAPKs](https://t.me/NekogramAPKs)
*   GBox 官方频道:[https://t.me/GBoxTGC](https://t.me/GBoxTGC)
*   LifeAnalysis Lab 更新:[https://t.me/lalab](https://t.me/lalab)
*   RSSHub 布告栏:[https://t.me/awesomeRSSHub](https://t.me/awesomeRSSHub)
*   Anti Revoke Plugin - 防撤回插件:[https://t.me/AntiRevoke](https://t.me/AntiRevoke)
*   Typecho Dev Channel:[https://t.me/typechodev](https://t.me/typechodev)

###### 媒体

*   Telegram 中文 NEWS:[https://t.me/YinxiangBiji_News](https://t.me/YinxiangBiji_News)
*   阿里云盘发布频道:[https://t.me/Aliyundrive_Share_Channel](https://t.me/Aliyundrive_Share_Channel)
*   Alist资源频道:[https://t.me/alistshare](https://t.me/alistshare)
*   科技花（TestFlight）:[https://t.me/TestFlightCN](https://t.me/TestFlightCN)
*   海龙说:[https://t.me/haotalk](https://t.me/haotalk)
*   不客观 Not Objective:[https://t.me/notobjective](https://t.me/notobjective)
*   卖桃者说（池建强）:[https://t.me/mactalk](https://t.me/mactalk)
*   澳门政府官方 Telegram 頻道:[https://t.me/leehsienloong](https://t.me/leehsienloong)
*   《澳門日報》官方 Telegram 頻道:[https://t.me/macaodaily](https://t.me/macaodaily)
*   The President of Brazil:[https://t.me/jairbolsonarobrasil](https://t.me/jairbolsonarobrasil)
*   The President of Turkey:[https://t.me/RTErdogan](https://t.me/RTErdogan)
*   The President of Mexico:[https://t.me/PresidenteAMLO](https://t.me/PresidenteAMLO)
*   The President of France:[https://t.me/emmanuelmacron](https://t.me/emmanuelmacron)
*   The Prime Minster of Singapore:[https://t.me/leehsienloong](https://t.me/leehsienloong)
*   The President of Ukraine:[https://t.me/V_Zelenskiy_official](https://t.me/V_Zelenskiy_official)
*   The President of Uzbekistan:[https://t.me/shmirziyoyev](https://t.me/shmirziyoyev)
*   The President of Taiwan:[https://t.me/iingtw](https://t.me/iingtw)
*   The Prime Minister of Ethiopia:[https://t.me/AbiyAhmedAliofficial](https://t.me/AbiyAhmedAliofficial)
*   The Prime Minister of Israel:[https://t.me/bnetanyahu](https://t.me/bnetanyahu)
*   Donald Trump Jr:[https://t.me/TrumpJr](https://t.me/TrumpJr)
*   看鉴中国 OutsightChina:[https://t.me/OutsightChina](https://t.me/OutsightChina)
*   新闻实验室:[https://t.me/newslab2020](https://t.me/newslab2020)
*   60 秒读懂世界:[https://t.me/SharedResources](https://t.me/SharedResources)
*   突发新闻:[https://t.me/breakingnews_t](https://t.me/breakingnews_t)
*   南方周末 / Southern Weekly:[https://t.me/infzm](https://t.me/infzm)
*   zaobao.sg 早报 + 晚报 + 新明新闻:[https://t.me/zaobaosg](https://t.me/zaobaosg)
*   PixelExperience - News:[https://t.me/PixelExperience](https://t.me/PixelExperience)
*    Apple Nuts:[https://t.me/AppleNuts](https://t.me/AppleNuts)
*    Apple Spyder 果蛛 🕷️:[https://t.me/AppleSpyder](https://t.me/AppleSpyder)
*   AppPie:[https://t.me/AppPie](https://t.me/AppPie)
*   OnePlus™:[https://t.me/OnePlus](https://t.me/OnePlus)
*   程序员技术资源分享:[https://t.me/gotoshare](https://t.me/gotoshare)
*   大虾的编程资源库 / 码农 / 程序员资源:[https://t.me/programmingsrchub](https://t.me/programmingsrchub)
*   每日 AWESOME 观察:[https://t.me/awesomeopensource](https://t.me/awesomeopensource)
*   每日无数猫:[https://t.me/miaowu](https://t.me/miaowu)
*   IPN 播客网络:[https://t.me/ipnpodcast](https://t.me/ipnpodcast)
*   《無次元》博客:[https://t.me/wuciyuan](https://t.me/wuciyuan)
*   一天世界 博客:[https://t.me/yitianshijie](https://t.me/yitianshijie)
*   津津乐道播客:[https://t.me/jinjinledao](https://t.me/jinjinledao)
*   电丸科技 AK:[https://t.me/joinchat/AAAAAEWbURDTisztrTcwqA](https://t.me/joinchat/AAAAAEWbURDTisztrTcwqA)
*   随机波动 StochasticVolatility:[https://t.me/StochasticVolatilityPodcast](https://t.me/StochasticVolatilityPodcast)
*   精选中文播客:[https://t.me/chinapodcast](https://t.me/chinapodcast)
*   读舍 FM:[https://t.me/bookcn](https://t.me/bookcn)
*   新蛤社 TG 膜蛤专栏:[https://t.me/XinHaNewsAgency](https://t.me/XinHaNewsAgency)
*   回形针 PaperClip & 灵光灯泡:[https://t.me/papercliphub](https://t.me/papercliphub)
*   Ingress 官方频道:[https://t.me/NianticOfficial](https://t.me/NianticOfficial)
*   Steam 快讯:[https://t.me/steamsteam](https://t.me/steamsteam)
*   Programmer Jokes:[https://t.me/programmerjokes](https://t.me/programmerjokes)
*   BooksThief:[https://t.me/BooksThief](https://t.me/BooksThief)
*   Creative Motion:[https://t.me/creativemotion](https://t.me/creativemotion)
*   Google:[https://t.me/google](https://t.me/google)
*   Solidot（奇客的资讯，重要的东西）:[https://t.me/solidot](https://t.me/solidot)
*   ReadHub:[https://t.me/readhub_cn](https://t.me/readhub_cn)
*   少数派:[https://t.me/sspai](https://t.me/sspai)
*   XDA-Developers Hub:[https://t.me/xdadevelopershub](https://t.me/xdadevelopershub)
*   XDA-News [Official]:[https://t.me/xdanews](https://t.me/xdanews)
*   Linux 中国:[https://t.me/linuxdotcn](https://t.me/linuxdotcn)
*   BIGDONGDONG 频道:[https://t.me/bigdongdongchannel](https://t.me/bigdongdongchannel)
*   GroupHub 广播站:[https://t.me/GroupHub](https://t.me/GroupHub)
*   数字优惠:[https://t.me/DigitalSpecialDeals](https://t.me/DigitalSpecialDeals)
*   Equal Leaks:[https://t.me/EqualLeaks](https://t.me/EqualLeaks)
*   WooMai’s Channel:[https://t.me/WooMaiChannel](https://t.me/WooMaiChannel)
*   MrKevin 博客 资讯 分享 测评:[https://t.me/hilinuxcn](https://t.me/hilinuxcn)
*   Leonn 的博客:[https://t.me/liyuans](https://t.me/liyuans)
*   主机百科资讯分享:[https://t.me/zhujiwiki_info](https://t.me/zhujiwiki_info)
*   Affyun.com - 每日 offers 优选:[https://t.me/affyunpush](https://t.me/affyunpush)
*   VPS 仓 - 推荐 / 补货提醒:[https://t.me/vpscang](https://t.me/vpscang)
*   VPS 信号旗播报:[https://t.me/vps_xhq](https://t.me/vps_xhq)
*   unwire.hk 生活科技頻道:[https://t.me/unwire](https://t.me/unwire)
*   互联网从业者充电站:[https://t.me/https1024](https://t.me/https1024)
*   cnBeta.COM 中文业界资讯站 (简中):[https://t.me/cnbeta_com](https://t.me/cnbeta_com)
*   cnBeta.COM 中文業界資訊站 (繁中):[http://t.me/cnbeta_com_hk](http://t.me/cnbeta_com_hk)
*   每日消费电子观察:[https://t.me/CE_Observe](https://t.me/CE_Observe)
*   乌鸦观察:[https://t.me/bigcrowdev](https://t.me/bigcrowdev)
*   中国数字时代消息推送:[https://t.me/cdtchinesefeed](https://t.me/cdtchinesefeed)
*   网络安全技术频道:[https://t.me/tg_InternetSecurity](https://t.me/tg_InternetSecurity)
*   Google Drive 资源:[https://t.me/gdsharing](https://t.me/gdsharing)
*   Licenses Channel:[https://t.me/Licensesss](https://t.me/Licensesss)
*   [合租通知] Netflix YouTube Spotify office365 Hbo Surge 美剧:[https://t.me/hezu2](https://t.me/hezu2)
*   奈飞小铺:[https://t.me/netflix_bus](https://t.me/netflix_bus)
*   奈菲影视:[https://t.me/nfnfgroup](https://t.me/nfnfgroup)
*   4K 影视资源:[https://t.me/Remux_2160P](https://t.me/Remux_2160P)
*   4K 影视屋 - 蓝光无损电影:[https://t.me/dianying4K](https://t.me/dianying4K)
*   Emby 影视资源发布:[https://t.me/Plus_Movie_Best](https://t.me/Plus_Movie_Best)
*   卷毛鼠 - 影视频道:[https://t.me/CurlyMouse](https://t.me/CurlyMouse)
*   好莱坞影视:[https://t.me/HLWYS](https://t.me/HLWYS)
*   电影爱好者:[https://t.me/MovieAnywhere](https://t.me/MovieAnywhere)
*   音乐库:[https://t.me/MusicSharePlatform](https://t.me/MusicSharePlatform)
*   网络资源共享库:[https://t.me/Sharedspace](https://t.me/Sharedspace)
*   YouTube-ImShuker 文件及公告:[https://t.me/shukerxiaoxi](https://t.me/shukerxiaoxi)
*   电报时报:[https://t.me/times001](https://t.me/times001)
*   PUSH 科技快讯:[https://t.me/Pushings](https://t.me/Pushings)
*   逆风社:[https://t.me/nifengpress](https://t.me/nifengpress)
*   新纪元 新闻中心:[https://t.me/xinjiyuan9](https://t.me/xinjiyuan9)
*   吾爱资源 薅羊毛・资讯中心:[https://t.me/Pojieapp](https://t.me/Pojieapp)
*   🎏「 彼岸情报🔎！」🎏薅羊毛情报见闻社:[https://t.me/BaccanoSoul](https://t.me/BaccanoSoul)
*   此岸情报局:[https://t.me/JustReformation](https://t.me/JustReformation)
*   🅻ihaiba 资源羊毛分享🍭:[https://t.me/lihaiba](https://t.me/lihaiba)
*   频道🏆资源福利分享:[https://t.me/freemorebest](https://t.me/freemorebest)
*   推特|OnlyFans女菩萨:[https://t.me/xnvpux](https://t.me/xnvpux)
*   Google Play 限免信息:[https://t.me/playsales](https://t.me/playsales)
*   扫地僧笔记:[https://t.me/lover_links](https://t.me/lover_links)
*   Science:[https://t.me/science](https://t.me/science)
*   Gif Center:[https://t.me/gifcenter](https://t.me/gifcenter)
*   Wallpapers:[https://t.me/AR72014](https://t.me/AR72014)
*   Wallpapers/Обои:[https://t.me/EZwalls](https://t.me/EZwalls)
*   Wallpapers By Arthwork:[https://t.me/arthwork](https://t.me/arthwork)
*   Wallpapers And Art:[https://t.me/pfff_wall](https://t.me/pfff_wall)
*   壁纸 wallpapers:[https://t.me/bizhi123](https://t.me/bizhi123)
*   Hk3ToN:[https://t.me/Hk3To](https://t.me/Hk3To)
*   Wallpaper@Winn 手工壁纸分享:[https://t.me/WallpaperWinn](https://t.me/WallpaperWinn)
*   最美壁纸 © 极简派:[https://t.me/yidu520](https://t.me/yidu520)
*   iWallpaper PC:[https://t.me/iWallpaperPC](https://t.me/iWallpaperPC)
*   Dynamic Wallpaper Club:[https://t.me/dynamicwallpaperclub](https://t.me/dynamicwallpaperclub)
*   Tech Guide:[https://t.me/TechGuide](https://t.me/TechGuide)
*   Boring Class:[https://t.me/BoringClass](https://t.me/BoringClass)
*   Think Positive Words:[https://t.me/thinkpositivewords](https://t.me/thinkpositivewords)
*   乙烷日报:[https://t.me/OverDaily](https://t.me/OverDaily)
*   LetITFly News:[https://t.me/LetITFlyW](https://t.me/LetITFlyW)
*   安全上网，注意事项:[https://t.me/anquanshangwang](https://t.me/anquanshangwang)
*   竹新社:[https://t.me/tnews365](https://t.me/tnews365)
*   竹新资料库:[https://t.me/kt_database](https://t.me/kt_database)
*   海外媒体的中文新闻:[https://t.me/chinanews001](https://t.me/chinanews001)
*   《維基人》官方推播頻道:[https://t.me/the_Wikipedian](https://t.me/the_Wikipedian)
*   中文維基新聞廣播頻道:[https://t.me/wikinews_zh_broadcast](https://t.me/wikinews_zh_broadcast)
*   Reuters:World:[https://t.me/ReutersWorldChannel](https://t.me/ReutersWorldChannel)
*   每日沙雕墙:[https://t.me/woshadiao](https://t.me/woshadiao)
*   糗事百科:[https://t.me/qiushibaike](https://t.me/qiushibaike)
*   PUSH 科学快讯:[https://t.me/pushings](https://t.me/pushings)
*   少数人知道的消息:[https://t.me/csrinfo](https://t.me/csrinfo)
*   科技圈的日常:[https://t.me/misakatech](https://t.me/misakatech)
*   免費資源網路社群 Free Group:[https://t.me/Free_Group](https://t.me/Free_Group)
*   好物・羊毛收割机:[https://t.me/ZH_wool](https://t.me/ZH_wool)
*   Λ-Reading:[https://t.me/GoReading](https://t.me/GoReading)
*   网络安全中心:[https://t.me/tgdailigg](https://t.me/tgdailigg)
*   iOS 越狱插件更新信息:[https://t.me/Jailbreak_Tweaks](https://t.me/Jailbreak_Tweaks)
*   Jailbreak Notifications:[https://t.me/jailbreaknotifications](https://t.me/jailbreaknotifications)
*   Cydia Updates:[https://t.me/cydiaupdate](https://t.me/cydiaupdate)
*   Spotify News:[https://t.me/spotifynews](https://t.me/spotifynews)
*   全网福利收集:[https://t.me/AlltheChannel](https://t.me/AlltheChannel)
*   每日 AWESOME 观察:[https://t.me/awesomeopensource](https://t.me/awesomeopensource)
*   IT 那点事:[https://t.me/InternetNewsCN](https://t.me/InternetNewsCN)
*   即刻精选:[https://t.me/jike_collection](https://t.me/jike_collection)
*   机场防御测压实验室:[https://t.me/ssrcy](https://t.me/ssrcy)
*   XDDOS 压力测试:[https://t.me/xddos2](https://t.me/xddos2)
*   悟空干货集中营:[https://t.me/daily5kong](https://t.me/daily5kong)
*   LIFETIME 视界:[https://t.me/lifetimecn](https://t.me/lifetimecn)
*   Cloudflare 在中国频道:[https://t.me/Cloudflare_CN](https://t.me/Cloudflare_CN)
*   PT 资讯频道:[https://t.me/privatetrackernews](https://t.me/privatetrackernews)
*   Iyouport:[https://t.me/iyouport](https://t.me/iyouport)
*   o1xhack & friends🥤 分享 思考 科技 生活:[https://t.me/o1xinsight](https://t.me/o1xinsight)
*   Newlearner の自留地:[https://t.me/NewlearnerChannel](https://t.me/NewlearnerChannel)
*   NewlearnerのIT社群:[https://t.me/NewlearnerGroup](https://t.me/NewlearnerGroup)
*   Awesome Collection:[https://t.me/awesome_collection](https://t.me/awesome_collection)
*   Picacomic News:[https://t.me/PicACG](https://t.me/PicACG)
*   Apple Tech News:[https://t.me/appletechnews](https://t.me/appletechnews)
*   Android Weekly Update:[https://t.me/update4weekly](https://t.me/update4weekly)
*   码力全开工作室:[https://t.me/maliquankai](https://t.me/maliquankai)
*   数字移民:[https://t.me/shuziyimin](https://t.me/shuziyimin)
*   路透中文网:[https://t.me/lutouzhongwen_rss](https://t.me/lutouzhongwen_rss)
*   纽约时报:[https://t.me/niuyueshibao_rss](https://t.me/niuyueshibao_rss)
*   美国之音:[https://t.me/meiguozhiyin_rss](https://t.me/meiguozhiyin_rss)
*   知乎日报:[https://t.me/zhihuribao_rss](https://t.me/zhihuribao_rss)
*   BBC 中文:[https://t.me/bbczhongwen_rss](https://t.me/bbczhongwen_rss)
*   FT 中文网:[https://t.me/ftzhongwen_rss](https://t.me/ftzhongwen_rss)
*   双语新闻:[https://t.me/shuangyunews_rss](https://t.me/shuangyunews_rss)
*   法国 国际广播电台:[https://t.me/rfi_rss](https://t.me/rfi_rss)
*   德国 德国之声:[https://t.me/dw_rss](https://t.me/dw_rss)
*   澳大利亚 广播公司:[https://t.me/abc_rss](https://t.me/abc_rss)
*   俄罗斯 卫星通讯社:[https://t.me/ru_rss](https://t.me/ru_rss)
*   新加坡 联合早报:[https://t.me/sg_rss](https://t.me/sg_rss)
*   韩国 中央日报:[https://t.me/korea_rss](https://t.me/korea_rss)
*   日本 日经中文网:[https://t.me/jp_rss](https://t.me/jp_rss)
*   台湾香港 当地日报:[https://t.me/ttww_rss](https://t.me/ttww_rss)
*   每日早间新闻:[https://t.me/zaobaoNews](https://t.me/zaobaoNews)
*   经济信息联播:[https://t.me/eco_cn](https://t.me/eco_cn)
*   Learn SwiftUI:[https://t.me/learnswiftui](https://t.me/learnswiftui)
*   媒奇葩说:[https://t.me/mtalk](https://t.me/mtalk)
*   看理想 vistopia:[https://t.me/ikanlixiang](https://t.me/ikanlixiang)
*   Streaming Link Station:[https://t.me/streaming_link_station](https://t.me/streaming_link_station)
*   方可成的新闻实验室:[https://t.me/newslab2020](https://t.me/newslab2020)
*   Wolley News:[https://t.me/wolleynews](https://t.me/wolleynews)
*   Justf News:[https://t.me/justfNew](https://t.me/justfNew)
*   Hacker News:[https://t.me/hacker_news_feed](https://t.me/hacker_news_feed)
*   NewMobileLife:[https://t.me/newmobilelife](https://t.me/newmobilelife)
*   國家地理雜誌 中文版:[https://t.me/natgeomedia](https://t.me/natgeomedia)
*   你有一个打折需要了解:[https://t.me/SteamNy](https://t.me/SteamNy)
*   Emby 全能服务器体验（嘎鱼饭）:[https://t.me/gayufan](https://t.me/gayufan)
*   Trending Stickers:[https://t.me/TrendingStickers](https://t.me/TrendingStickers)
*   KAIX.IN:[https://t.me/kaix_in](https://t.me/kaix_in)
*   TSBBLOG:[https://t.me/tsbblog](https://t.me/tsbblog)
*   中文播客精选:[https://t.me/greatpodcasts](https://t.me/greatpodcasts)
*   每日一歌:[https://t.me/dailymusich](https://t.me/dailymusich)
*   音乐世界:[https://t.me/lumingguandj](https://t.me/lumingguandj)
*   中文社科讲座资讯:[https://t.me/chwebinars](https://t.me/chwebinars)
*   【ZERO】安全运营（DevSecOps）:[https://t.me/zero_devsecops](https://t.me/zero_devsecops)
*   小报频道:[https://t.me/FQnews](https://t.me/FQnews)
*   维生素 E:[https://t.me/vitamineEpodcast](https://t.me/vitamineEpodcast)
*   Beta News:[https://t.me/appbetanews](https://t.me/appbetanews)
*   geekhub 苹果团:[https://t.me/geekhub_com](https://t.me/geekhub_com)
*   Hardcore English Channel:[https://t.me/hardcorengch](https://t.me/hardcorengch)
*   TikTok 抖音短视频:[https://t.me/TiktokA3](https://t.me/TiktokA3)
*   阿里云盘:[https://t.me/YunPanPan](https://t.me/YunPanPan)
*   阿里云盘资源发布频道:[https://t.me/shareAliyun](https://t.me/shareAliyun)
*   二手🐴:[https://t.me/SecHorse](https://t.me/SecHorse)
*   用爱发电俱乐部:[https://t.me/NotionFans](https://t.me/NotionFans)


###### 其他

*   频道 / 群组 / 机器人分享:[https://t.me/hao123f](https://t.me/hao123f)
*   Animated Stickers:[https://t.me/AnimatedStickers](https://t.me/AnimatedStickers)
*   Animated Emojis:[https://t.me/AnimatedEmojis](https://t.me/AnimatedEmojis)
*   本土創作的貼圖:[https://t.me/LocalStickers](https://t.me/LocalStickers)
*   Stickers Channel:[https://t.me/stickersChannel](https://t.me/stickersChannel)
*   ACG Stickers:[https://t.me/ACGStickers](https://t.me/ACGStickers)
*   TestFlight News:[https://t.me/testflights](https://t.me/testflights)
*   My Desctop（Cool 4k, HD wallpapers）:[https://t.me/PhoneDesctop](https://t.me/PhoneDesctop)
*   Gramip Channel:[https://t.me/Gramip](https://t.me/Gramip)
*   秘密文摘:[https://t.me/secretofbody_degist](https://t.me/secretofbody_degist)
*   Sync 资源更新:[https://t.me/shenkey](https://t.me/shenkey)
*   zrj766 的频道:[https://t.me/zrj96](https://t.me/zrj96)
*   Host Testing and evaluation:[https://t.me/HostEvaluate](https://t.me/HostEvaluate)
*   Free 網絡信息自由門:[https://t.me/todayfreedom](https://t.me/todayfreedom)
*   Ingress 中文:[https://t.me/IngressChinese](https://t.me/IngressChinese)
*   Ingress Chengdu&Chongqing:[https://t.me/IngressChengduChongqing](https://t.me/IngressChengduChongqing)
*   FindYanot Ch:[https://t.me/findyanotch](https://t.me/findyanotch)
*   豆瓣精选:[https://t.me/douban_read](https://t.me/douban_read)
*   文杏馆（藏书分享）:[https://t.me/BooksThatMakeYouThink](https://t.me/BooksThatMakeYouThink)
*   【程序员之家】软件项目百例:[https://t.me/useless_project_ideas](https://t.me/useless_project_ideas)
*   好书分享:[https://t.me/haoshufenxiang](https://t.me/haoshufenxiang)
*   每周一书:[https://t.me/weekly_books](https://t.me/weekly_books)
*   ZBook，精品电子书:[https://t.me/ziyuanfeng59](https://t.me/ziyuanfeng59)
*   ReadFine 电子书屋:[https://t.me/Readfine](https://t.me/Readfine)
*   计算机与部分其他种类书籍资源:[https://t.me/bookusefor2](https://t.me/bookusefor2)
*   计算机类书籍:[https://t.me/bookusefor3](https://t.me/bookusefor3)
*   编程随想推荐书籍（非官方）:[https://t.me/programthinkbooks](https://t.me/programthinkbooks)
*   電書攤Ƹ̵̡Ӝ̵̨Ʒ:[https://t.me/telebookstall](https://t.me/telebookstall)
*   好书分享频道:[https://t.me/haoshufenxiang](https://t.me/haoshufenxiang)
*   山巅出版社:[https://t.me/shandian2084](https://t.me/shandian2084)
*   zread (推) - 什么书值得读:[https://t.me/zreadpush](https://t.me/zreadpush)
*   微信搬运工:[https://t.me/WeChatEssence](https://t.me/WeChatEssence)
*   蛋挞报:[https://t.me/pincongessence](https://t.me/pincongessence)
*   台湾的一个可爱 Sticker Channel:[https://t.me/sticker_tw](https://t.me/sticker_tw)
*   发猫频道猫奴必备:[https://t.me/miaowu](https://t.me/miaowu)
*   今天 tg 打掉了几个 ISIS bot:[https://t.me/ISISwatch](https://t.me/ISISwatch)
*   老毛子 Padavan 固件发布:[https://t.me/pdcn1](https://t.me/pdcn1)
*   老毛子 Padavan 固件纯净交流群:[https://t.me/pdcn0](https://t.me/pdcn0)
*   eSir Playground 固件 & 插件发布频道:[https://t.me/joinchat/AAAAAE-8dVyO8ljrgQ5yCw](https://t.me/joinchat/AAAAAE-8dVyO8ljrgQ5yCw)
*   图拉鼎的所见、所闻、所想:[https://t.me/tualatrix_says](https://t.me/tualatrix_says)
*   Better Naming:[https://t.me/rebornix](https://t.me/rebornix)
*   某不科学的 DIYgod:[https://t.me/awesomeDIYgod](https://t.me/awesomeDIYgod)
*   Kindle 电子书降价信息:[https://t.me/kindlePrice](https://t.me/kindlePrice)
*   Kindle 特价书:[https://t.me/KindleBookDeals](https://t.me/KindleBookDeals)
*   亚马逊 Amazon 每日热销、降价榜:[https://t.me/amazonhotevery](https://t.me/amazonhotevery)
*   Amazon 降价信息:[https://t.me/amazondrop](https://t.me/amazondrop)
*   Premium 🇵 🇷 🇴💀:[https://t.me/Premiumpro](https://t.me/Premiumpro)
*   饭否每日精选:[https://t.me/fanfou_daily](https://t.me/fanfou_daily)
*   饭否每周精选:[https://t.me/fanfou_weekly](https://t.me/fanfou_weekly)
*   Scale system:[https://t.me/scalesystem](https://t.me/scalesystem)
*   一任阶前点滴到天明:[https://t.me/hearrain](https://t.me/hearrain)
*   Inbox 收集箱:[https://t.me/inbox_all](https://t.me/inbox_all)
*   冷眼向洋:[https://t.me/lengyanxiangyang](https://t.me/lengyanxiangyang)
*   Dribbble Popular Design 每日流行设计:[https://t.me/designtaalk](https://t.me/designtaalk)
*   Google Voice 靓号:[https://t.me/voice_google](https://t.me/voice_google)
*   Jailbreak News:[https://t.me/jailbreaknotifications](https://t.me/jailbreaknotifications)
*   看看就好:[https://t.me/swiminthedream](https://t.me/swiminthedream)
*   荔枝木:[https://t.me/lychee_wood](https://t.me/lychee_wood)
*   每日摄影观察:[https://t.me/cnphotog_collect](https://t.me/cnphotog_collect)
*   GroupOwnerBots:[https://t.me/GroupOwnerBots](https://t.me/GroupOwnerBots)
*   一休儿的哲学讲座:[https://t.me/yixiuer](https://t.me/yixiuer)
*   小破不入渠:[https://t.me/forwardlikehell](https://t.me/forwardlikehell)
*   Netflix 高分好剧推介:[https://t.me/NetflixFans](https://t.me/NetflixFans)
*   Netflix 影片介绍:[https://t.me/NetflixFirst](https://t.me/NetflixFirst)
*   RARTV:[https://t.me/rartv](https://t.me/rartv)
*   财经快讯:[https://t.me/fnnew](https://t.me/fnnew)
*   黑洞资源共享:[https://t.me/tieliu](https://t.me/tieliu)
*   SitandRelax’s Channel~NSFW:[https://t.me/SitandRelaxLabs](https://t.me/SitandRelaxLabs)
*   Jerry Zhāng 的频道:[https://t.me/JerryZhang](https://t.me/JerryZhang)
*   SaoDaye - TG 频道:[https://t.me/infosaodaye](https://t.me/infosaodaye)
*   EMK Public Channel:[https://t.me/JacobEMK](https://t.me/JacobEMK)
*   摄神取念:[https://t.me/Legolimens](https://t.me/Legolimens)
*   For Work 系列 - 梗频道:[https://t.me/JISFW](https://t.me/JISFW)
*   For Work 系列 - 图频道:[https://t.me/GfWR16](https://t.me/GfWR16)
*   For Work 系列 - 读频道:[https://t.me/NewsFW](https://t.me/NewsFW)
*   For Work 系列 - 妹频道:[https://t.me/GFW3DS](https://t.me/GFW3DS)
*   For Work 系列 - NLP 频道:[https://t.me/NLPfW](https://t.me/NLPfW)
*   For Work 系列 - 轨道群:[https://t.me/RailwayFW](https://t.me/RailwayFW)
*   Sukka’s Notebook:[https://t.me/SukkaChannel](https://t.me/SukkaChannel)
*   David’s YouTube 频道推荐:[https://t.me/davidsyoutube](https://t.me/davidsyoutube)
*   tesla 特斯拉 / 科技 NEWS:[https://t.me/Tesla_share](https://t.me/Tesla_share)
*   搞机日记:[https://t.me/gcjiriji](https://t.me/gcjiriji)
*   烤苹果 (专业收集 bug):[https://t.me/AppleCooked](https://t.me/AppleCooked)
*   Foolish TraceWind:[https://t.me/FoolishTraceWind](https://t.me/FoolishTraceWind)
*   tg 机器人推荐:[https://t.me/tgbotlist](https://t.me/tgbotlist)
*   物与民胞:[https://t.me/unicorn4kk](https://t.me/unicorn4kk)
*   DLK 搞笑趣闻情报站:[https://t.me/dlkqingbaozhan](https://t.me/dlkqingbaozhan)
*   毒奶频道 🅥 limboPro.xyz:[https://t.me/limboprossr](https://t.me/limboprossr)
*   OurBits RSS 频道:[https://t.me/OurBits_RSS](https://t.me/OurBits_RSS)
*   ZUOLUOTV 官方频道:[https://t.me/zuoluotvofficial](https://t.me/zuoluotvofficial)
*   不求甚解:[https://t.me/fakeye](https://t.me/fakeye)
*   煎蛋无聊图:[https://t.me/jiandan_bored](https://t.me/jiandan_bored)
*   上班划水之沙雕图:[https://t.me/goworkbitch](https://t.me/goworkbitch)
*   美图与沙雕:[https://t.me/shadiaotu](https://t.me/shadiaotu)
*   心惊报:[https://t.me/xinjingdaily](https://t.me/xinjingdaily)
*   微博热搜:[https://t.me/weibo_hot](https://t.me/weibo_hot)
*   土味生活:[https://t.me/tuweishenghuo](https://t.me/tuweishenghuo)
*   初恋的感觉:[https://t.me/chuliandeganjue](https://t.me/chuliandeganjue)
*   笑掉大牙:[https://t.me/xiaodiaodaya](https://t.me/xiaodiaodaya)
*   Zapro Notice:[https://t.me/zaproshare](https://t.me/zaproshare)
*   The Sociologist:[https://t.me/thesoc](https://t.me/thesoc)
*   科技无意义:[https://t.me/technical_with_love](https://t.me/technical_with_love)
*   𝐕 𝐀 𝐆 𝐔 𝐄 - 針:[https://t.me/oz_sensei](https://t.me/oz_sensei)
*   Sean:[https://t.me/SeanChannel](https://t.me/SeanChannel)
*   Outvivid:[https://t.me/outvivid](https://t.me/outvivid)
*   Reuters: World:[https://t.me/ReutersWorldChannel](https://t.me/ReutersWorldChannel)
*   zrj766 的频道:[https://t.me/zrj96](https://t.me/zrj96)
*   IMG2D:[https://t.me/IMG2D](https://t.me/IMG2D)
*   PT 资讯频道:[https://t.me/privatetrackernews](https://t.me/privatetrackernews)
*   Rachel 碎碎念:[https://t.me/RachelBlahblah](https://t.me/RachelBlahblah)
*   Rachel 的消息发布站点:[https://t.me/RachelNotice](https://t.me/RachelNotice)
*   Telegram China News:[https://t.me/tgchinanews](https://t.me/tgchinanews)
*   📊 Polls Channel:https://t.me/polls_channel
*   浅影随想:[https://t.me/lightFantasy](https://t.me/lightFantasy)
*   杂物:[https://t.me/zaawuu](https://t.me/zaawuu)
*   螺莉莉的黑板报:[https://t.me/im_RORIRI](https://t.me/im_RORIRI)
*   锤子🔨丨网球🎾丨圈❎:[https://t.me/ThorHCC](https://t.me/ThorHCC)
*   APPDO 数字生活指南:[https://t.me/appdodo](https://t.me/appdodo)
*   资源垃圾佬:[https://t.me/allfree123](https://t.me/allfree123)
*   老梁故事汇:[https://t.me/Laoliang666](https://t.me/Laoliang666)
*   科学上网资源整合:[https://t.me/ysl_channel](https://t.me/ysl_channel)
*   自留 𝙘𝙝𝙖𝙣𝙣𝙚𝙡 > 𝙢𝙖𝙞𝙘𝙤𝙤 / 𝙍𝙪𝙡𝙚𝙨:[https://t.me/who_channel](https://t.me/who_channel)
*   美剧←→blahblah (& etc.):[https://t.me/mytvseries](https://t.me/mytvseries)
*   All About RSS:[https://t.me/aboutrss](https://t.me/aboutrss)
*   NS 新闻转报:[https://t.me/SwitchNewCN](https://t.me/SwitchNewCN)
*   rynco libkadence:[https://t.me/rynif](https://t.me/rynif)
*   庭说 TingTalk:[https://t.me/tingtalk](https://t.me/tingtalk)
*   叨庭涂说 TingTalk Everything:[https://t.me/tingtalk_all](https://t.me/tingtalk_all)
*   海贼王 One Piece 动漫更新提醒:[https://t.me/tingtalk_op](https://t.me/tingtalk_op)
*   PDF 资料:[https://t.me/pdf_001](https://t.me/pdf_001)
*   Apps 推广 / 抽奖 / 活动:[https://t.me/AppsSweepstakesNews](https://t.me/AppsSweepstakesNews)
*   边走边吃的夏天:[https://t.me/deliciousxia](https://t.me/deliciousxia)
*   moke 的 日常分享、吐槽和动态:[https://t.me/mokeyjay_channel](https://t.me/mokeyjay_channel)
*   台灣蘋果同好群 - 佈告板:[https://t.me/TWAppleFansAnnounce](https://t.me/TWAppleFansAnnounce)
*   烤苹果:[https://t.me/AppleCooked](https://t.me/AppleCooked)
*   内核怕怕 - 辣鸡 Linux:[https://t.me/kernelscared](https://t.me/kernelscared)
*   辣鸡咕鸽毁我信仰 #CurryMyLife:[https://t.me/googleshit](https://t.me/googleshit)
*   TG… 药丸？:[https://t.me/tgpill](https://t.me/tgpill)
*   食屎啦 Niantic:[https://t.me/shitofniantic](https://t.me/shitofniantic)
*   如何与沙雕相处:[https://t.me/ruheyushadiaoxiangchu](https://t.me/ruheyushadiaoxiangchu)
*   空空如也:[https://t.me/MomoKCH](https://t.me/MomoKCH)
*   85.60×53.98 卡粉订阅 / 提醒:[https://t.me/DocOfCard](https://t.me/DocOfCard)
*   小林君家里的托尔:[https://t.me/TooruchanNews](https://t.me/TooruchanNews)
*   托尔酱的梗图与 FW:[https://t.me/TooruChan_Memes](https://t.me/TooruChan_Memes)
*   一些干货:[https://t.me/youganhuo](https://t.me/youganhuo)
*   豆瓣知乎简书微信公众号:[https://t.me/dbzhjs](https://t.me/dbzhjs)
*   全球主流新闻媒体中文速览:[https://t.me/allzhnews](https://t.me/allzhnews)
*   校长读报:[https://t.me/XiaoZhangDuBao](https://t.me/XiaoZhangDuBao)
*   Godly Noob:[https://t.me/GodlyNews1](https://t.me/GodlyNews1)
*   每天趣事:[https://t.me/Meitian](https://t.me/Meitian)
*   奇趣百科:[https://t.me/qiqubaike](https://t.me/qiqubaike)
*   硬核小卒:[https://t.me/yinghexiaozu](https://t.me/yinghexiaozu)
*   电报中央电视台综合频道:[https://t.me/joinchat/AAAAAEhkwtQjONQXe--Z8g](https://t.me/joinchat/AAAAAEhkwtQjONQXe--Z8g)
*   报道者:[https://t.me/tw_reporter_org](https://t.me/tw_reporter_org)
*   性别偏见与性别议题:[https://t.me/daily_feminist](https://t.me/daily_feminist)
*   每日文章精选:[https://t.me/daily_read](https://t.me/daily_read)
*   行动派公民联盟:[https://t.me/citizen_united](https://t.me/citizen_united)
*   Matters 閲讀精選:[https://t.me/MattersHub](https://t.me/MattersHub)
*   灵感库:[https://t.me/uselessideas](https://t.me/uselessideas)
*   中国纪录片:[https://t.me/chinesedocumentary](https://t.me/chinesedocumentary)
*   👁‍🗨耳目💬:[https://t.me/earsandeyes](https://t.me/earsandeyes)
*   品葱搬运:[https://t.me/pincongessence](https://t.me/pincongessence)
*   重灌狂人:[https://t.me/briian](https://t.me/briian)
*   赚客吧:[https://t.me/zuanke8](https://t.me/zuanke8)
*   电报障害:[https://t.me/poorRideoReception](https://t.me/poorRideoReception)
*   莼🐔8️⃣混:[https://t.me/eessej](https://t.me/eessej)
*   📣文宣中国📣:[https://t.me/VoiceofCN](https://t.me/VoiceofCN)
*   一方天地:[https://t.me/world2us](https://t.me/world2us)
*   R.O.D.:[https://t.me/read_or_dead](https://t.me/read_or_dead)
*   人间指南:[https://t.me/renjianzhinan_channel](https://t.me/renjianzhinan_channel)
*   Classical Music:[https://t.me/exploreclassical](https://t.me/exploreclassical)
*   小胖的日常分享:[https://t.me/bettergoods](https://t.me/bettergoods)
*   Rynco 维护的版聊频道:[https://t.me/rynif](https://t.me/rynif)
*   Die Lichtung 林間空地:[https://t.me/dieLichtung](https://t.me/dieLichtung)
*   PhilTalk:[https://t.me/philchannel](https://t.me/philchannel)
*   Soha 的日常:[https://t.me/sohadays](https://t.me/sohadays)
*   CyanChannel:[https://t.me/CyanCh](https://t.me/CyanCh)
*   咕 Billchen 咕:[https://t.me/billchenla](https://t.me/billchenla)
*   pikapush:[https://t.me/pikapush](https://t.me/pikapush)
*   Laoself:[https://t.me/laoself](https://t.me/laoself)
*   诡异的鱼塘:[https://t.me/Memory_Of_Fish](https://t.me/Memory_Of_Fish)
*   Reference Error:[https://t.me/reference_error](https://t.me/reference_error)
*   Timmy Channel:[https://t.me/TimmyChannel](https://t.me/TimmyChannel)
*   喵喵小喵喵:[https://t.me/MeowMiniMeow](https://t.me/MeowMiniMeow)
*   FlyingSky’s Channel:[https://t.me/FlyingSky233](https://t.me/FlyingSky233)
*   今天 abc 看了啥:[https://t.me/abcthoughts](https://t.me/abcthoughts)
*   今日份的豆酱:[https://t.me/today_bean](https://t.me/today_bean)
*   蛋挞观察室:[https://t.me/ijustseesee](https://t.me/ijustseesee)
*   Arch Linux Chinese Messages:[https://t.me/archlinuxcn](https://t.me/archlinuxcn)
*   Arch Linux Updates:[https://t.me/archlinuxcn_updates](https://t.me/archlinuxcn_updates)
*   坐和放宽的碎碎念:[https://t.me/SitandRelaxW](https://t.me/SitandRelaxW)
*   HEMC Tech Tips:[https://t.me/SitandRelaxLab](https://t.me/SitandRelaxLab)
*   Polls Channel:[https://t.me/polls_channel](https://t.me/polls_channel)
*   pikapush:[https://t.me/pikapush](https://t.me/pikapush)
*   小林君家里的托尔 [Archived]:[https://t.me/TooruchanNews](https://t.me/TooruchanNews)
*   托尔酱的梗图与 FW:[https://t.me/TooruChan_Memes](https://t.me/TooruChan_Memes)
*   托尔随便拆拆:[https://t.me/TooruTeardowns](https://t.me/TooruTeardowns)
*   一个自由的画室 (大概):[https://t.me/free_stusio](https://t.me/free_stusio)
*   一个无聊透顶的频道 (大概）:[https://t.me/justAboringchannel](https://t.me/justAboringchannel)
*   ctlee61 Preview:[https://t.me/hictlee61](https://t.me/hictlee61)
*   傅 Sir 的船新世界:[https://t.me/newworldviafu](https://t.me/newworldviafu)
*   Lymbo@碎碎念:[https://t.me/lymbo_chatting](https://t.me/lymbo_chatting)
*   无籽水稻种植基地:[https://t.me/seedless_channel](https://t.me/seedless_channel)
*   音游沙雕频道:[https://t.me/yingyoushadiao](https://t.me/yingyoushadiao)
*   土间被活埋の公告板:[https://t.me/umr23333](https://t.me/umr23333)
*   为也行:[https://t.me/weiyexing](https://t.me/weiyexing)
*   通天阁_不止于学习:[https://t.me/tongtiange](https://t.me/tongtiange)
*   不存在的世界:[https://t.me/illusory_world](https://t.me/illusory_world)
*   Milkice’s NG:[https://t.me/milkice_portal](https://t.me/milkice_portal)
*   缤纷世界的彩色冒险:[https://t.me/bunte_Welt](https://t.me/bunte_Welt)
*   笔记本：句子摘抄:[https://t.me/LinsBookA](https://t.me/LinsBookA)
*   笔记本：好图收藏与整理:[https://t.me/linyunbook2](https://t.me/linyunbook2)
*   小黄车分享:[https://t.me/shortyellowbikeshare](https://t.me/shortyellowbikeshare)
*   电报新闻:[https://t.me/chinesenewss](https://t.me/chinesenewss)
*   MiaoTony’s Box:[https://t.me/MiaoTonyChannel](https://t.me/MiaoTonyChannel)
*   南国微雪:[https://t.me/TinySnow4Yi](https://t.me/TinySnow4Yi)
*   情话箱:[https://t.me/qinghua_box](https://t.me/qinghua_box)
*   哆啦 B 梦 ACG 绅士游戏分享:[https://t.me/dlbmeng1](https://t.me/dlbmeng1)
*   rvalue 的生草日常:[https://t.me/rvalue_daily](https://t.me/rvalue_daily)
*   Galgame 频道:[https://t.me/Galgamer_Channel](https://t.me/Galgamer_Channel)
*   大咕咕咕鸡:[https://t.me/dagudu](https://t.me/dagudu)
*   Menhera-Channel:[https://t.me/nanasekurumi](https://t.me/nanasekurumi)
*   风向旗参考快讯:[https://t.me/xhqcankao](https://t.me/xhqcankao)
*   SOGIE 讲座频道:[https://t.me/sogie_webinar](https://t.me/sogie_webinar)
*   Parallel Experiments:[https://t.me/LinghaoCh](https://t.me/LinghaoCh)
*   鹤望兰:[https://t.me/bpsheel](https://t.me/bpsheel)
*   Listen to Reza:[https://t.me/Listentoreza](https://t.me/Listentoreza)
*   书籍目录:[https://t.me/jumpto22222](https://t.me/jumpto22222)
*   悦读「优质少量 RSS 聚合」:[https://t.me/dailyrss](https://t.me/dailyrss)
*   新闻联播:[https://t.me/CCTVNewsBroadcast](https://t.me/CCTVNewsBroadcast)
*   一个兴趣使然的动漫切段频道:[https://t.me/xqsranimegif](https://t.me/xqsranimegif)
*   一个兴趣使然的 PC 壁纸频道:[https://t.me/CGSFW](https://t.me/CGSFW)
*   A Place Of Happiness:[https://t.me/get_happiness](https://t.me/get_happiness)
*   馒头的日常:[https://t.me/xiao_man_tou](https://t.me/xiao_man_tou)
*   Kartoshka:[https://t.me/sweet_kartoshka](https://t.me/sweet_kartoshka)
*   小岛电波:[https://t.me/biubiubiuchat](https://t.me/biubiubiuchat)
*   水水水博物馆:[https://t.me/water_water_water_2077](https://t.me/water_water_water_2077)
*   深夜电台：武志红心理学【完结】:[https://t.me/wuzhihongxinlixue](https://t.me/wuzhihongxinlixue)
*   卖女孩的杂货铺:[https://t.me/mxbababa2020](https://t.me/mxbababa2020)
*   知音:[https://t.me/Musiccnchannel](https://t.me/Musiccnchannel)
*   云上报刊亭:[https://t.me/magazinesclub](https://t.me/magazinesclub)
*   ASMR 优质分享:[https://t.me/asmrforme](https://t.me/asmrforme)
*   115 资源 - 懒狗集中营:[https://t.me/vip115hot](https://t.me/vip115hot)
*   教程课程分享:[https://t.me/fufeikc](https://t.me/fufeikc)
*   纪录片自留地:[https://t.me/litterpanda](https://t.me/litterpanda)
*   读・书:[https://t.me/readingeventhosting](https://t.me/readingeventhosting)
*   日常人间观察:[https://t.me/hayami_kiraa](https://t.me/hayami_kiraa)
*   In The Flux:[https://t.me/intheflux](https://t.me/intheflux)
*   無逸齋隨筆:[https://t.me/todayread](https://t.me/todayread)
*   落枕电波:[https://t.me/Bakage1016](https://t.me/Bakage1016)
*   屏浅隐狱:[https://t.me/peopleofscreen](https://t.me/peopleofscreen)
*   擅长搜索的高木同学:[https://t.me/gaomutongxue](https://t.me/gaomutongxue)
*   开源社区频道:[https://t.me/opencfdchannel](https://t.me/opencfdchannel)
*   精品搞笑 gif（频道）:[https://t.me/gaoxiaogif8](https://t.me/gaoxiaogif8)
*   車車的阁楼:[https://t.me/DuskPipe](https://t.me/DuskPipe)
*   Never mind:[https://t.me/ButNothingHappened](https://t.me/ButNothingHappened)
*   吴说区块链:[https://t.me/wublock](https://t.me/wublock)
*   币圈快讯:[https://t.me/btcnewsdaily](https://t.me/btcnewsdaily)
*   快讯猎手（重要版）:[https://t.me/zhongyaokuaixun](https://t.me/zhongyaokuaixun)
*   Find Blog👁发现博客:[https://t.me/findblog](https://t.me/findblog)
*   苍穹の下・SKY 的 Blog:[https://t.me/blueskyxnblog](https://t.me/blueskyxnblog)
*   瞎玩菌:[https://t.me/blindgamer](https://t.me/blindgamer)
*   Tesla China 🅥:[https://t.me/Teslacn](https://t.me/Teslacn)

##### 机器人 Bot

###### 官方认证 Bot

*   [BotFather](https://t.me/BotFather) 是所有机器人的 god 了，Telegram 官方管理；可以用它创建机器人和管理机器人，你可以利用机器人 API, 帮你自己很多事情
*   [IFTTT](https://t.me/IFTTT) ifttt 的官方机器人，可以很方便的和 ifttt 里的其他服务连接，比如订阅某个网站的 RSS, 如果有更新就会自动把 RSS 内容推送到这个机器人，减少了频繁刷新网站来获取新的内容
*   [GmailBot](https://t.me/GmailBot) 可以在这里就方便的收发 Gmail
*   [DiscussBot](https://t.me/discussbot) 官方出的评论机器人，可以在频道每条消息下面点击添加评论
*   [MTProxy Admin Bot](https://t.me/MTProxybot) 设置和管理 Telegram MTProto 服务器.
*   [Stickers](https://t.me/Stickers) 使用此机器人创建贴纸并获取贴纸的使用统计数据.
*   [SpamBot](https://t.me/SpamBot) 官方处理 spam 事务的机器人
*   [VerifyBot](https://t.me/VerifyBot) 官方认证账号的机器人
*   [Telegraph](https://t.me/telegraph) This bot can help you log in on Telegra.ph, manage your articles, and get page view statistics.
*   [Previews](https://t.me/previews) Use this bot to leave feedback about webpage previews generated for Telegram’s Instant View feature.
*   [Designers Bot](https://t.me/design_bot) This bot accepts UI layouts and animations intended to improve Telegram. Best contributions are published in @designers
*   [Jobs Bot](https://t.me/jobs_bot) This bot lists career opportunities at Telegram and accepts candidates’ applications. Available at telegram.org/jobs
*   [GDPR Bot](https://t.me/gdprbot) Telegram’s Official GDPR bot.
*   [GameBot](https://t.me/gamebot) I’m a demo bot for the Telegram Gaming Platform. I can get you a few fun sample games to play.
*   [ContestBot](https://t.me/ContestBot) ContestBot is a way for Telegram to hold online competitions and find new members for the Telegram team.
*   [QuizBot](https://t.me/QuizBot) Create a quiz with several multiple choice questions and test your friends.

###### 其他
*   [这个我知道](https://t.me/keyword_reply_bot) 本机器人能够自动回复关键词对应的内容
*   [这个我删了 Bot](https://t.me/keyworddel_bot) 自动删除’推广 / 广告 / 菠菜’等等消息
*   [Vultr 助手 Bot](https://t.me/vultr_helper_bot) 绑定 Vultr 账户，定时提醒 Vultr 账户的余额和流量不足信息
*   [Telegram 权限管理 Bot](https://t.me/autopm_bot) Telegram 自动管理权限，指定时间自动关闭 / 打开群组权限
*   [TGX - 频道秘书](https://t.me/zh_secretary_bot) Telegram 中文群组索引导航
*   [北极星搜索](https://t.me/PolarisseekBot) Telegram 中文群组索引导航
*   [超级索引](https://t.me/SuperIndexCNBot) Telegram 中文群组频道搜索机器人
*   [超级索引](https://t.me/hao1234bot) Telegram 中文群组频道搜索机器人
*   [TGCN - 群组频道狐](https://t.me/zh_groups_bot) Telegram 中文群组频道搜索机器人
*   [超级搜索](https://t.me/So1234Bot) Telegram 中文群组频道搜索机器人
*   [新频道群组导航](https://t.me/groups_cnbot) 新频道群组导航
*   [Translate Father](https://t.me/TranslateFather_bot) 翻译消息
*   [Yandex.Translate](https://t.me/YTranslateBot) 翻译消息
*   [Language Translator](https://t.me/ang_translate_bot) 翻译消息
*   [中英翻譯 (English Chinese (Mandarin) translation)](https://t.me/en_to_tw_bot) 翻译消息
*   [Sticker To GIF](https://t.me/Sticker2GIFBot) 贴纸下载，支持动态贴纸
*   [Sticker Downloader](https://t.me/Stickerdownloadbot) 贴纸下载
*   [StickerSetBot](https://t.me/stickerset2packbot) 贴纸下载
*   [TG Downloader](https://t.me/GIFDownloader_bot) GIF 和贴纸下载
*   [Manybot](https://t.me/Manybot) Manybot lets you create your own bots. Send messages, create custom commands and menus. Press Send message to begin
*   [ControllerBot](https://t.me/ControllerBot) Awesome bot for channel owners that helps you to create rich posts, view stats and more.
*   [vote](https://t.me/vote) 投票机器人，新建一个投票发布在群里，每一次投票都是实时显示结果的，结果会以十分直观的方式展示
*   [PTRankBot](https://t.me/PTRankBot) 可以帮助你搜索和分享 iOS/macOS 应用，只需要在聊天框输入 @PTRankBot 和关键字，等待几秒就会出现搜索结果。支持命令查看 Store 各种排名，如 /top_free 查看每周免费排行榜
*   [ehForwarderBot](https://t.me/EFBSupport) ehForwarderBot 能够将微信和 Telegram 连接在一起，你可以在 Telegram 上收发微信消息，详情查看:[https://meta.appinn.net/t/efb-v2-telegram-docker/10888](https://meta.appinn.net/t/efb-v2-telegram-docker/10888).GitHub 地址: [https://github.com/blueset/ehForwarderBot](https://github.com/blueset/ehForwarderBot)
*   [AirPollution_Bot](https://t.me/AirPollution_Bot) 查询空气质量 (AQI), 数据来源为 aqicn.org, 比如发送 “/aqi 成都” 就会立即返回你成都的空气质量
*   [temp_mail_bot](https://t.me/temp_mail_bot) 有效期 10 分钟临时邮箱服务，当你想要临时注册一个网站的账号时就可以用这种临时邮箱服务，避免自己的邮箱泄露也免于各种垃圾广告骚扰
*   [utubebot](https://t.me/utubebot) YouTube 视频下载或者音频转换服务，把 YouTube 的链接发过去它就会帮你转换格式并为你提供文件，便于你下载此视频
*   [apkdl_bot](https://t.me/apkdl_bot) Android APK 搜索和下载，输入 App 名即可提供多个来自国外网站 APK 下载链接，点 Preview 可以查看图标
*   [LikeBot](https://t.me/LikeBot) 一个很酷的机器人，用基于表情符号的按钮创建帖子，可以点击表情符号投票.
*   [Instasave_bot](https://t.me/Instasave_bot) 下载 Instagram 和 YouTube 的图片和视频
*   [Creation Date](https://t.me/creationdatebot) 查询你的 tg ID 和注册时间
*   [getidsbot](https://t.me/getidsbot) 查询你的 tg ID 和注册时间
*   [TGSoBot](https://t.me/TGSoBot) Telegram 中文圈内容搜索引擎，主要用于支持官方不友好的中文搜索，有任何资源该引擎可以做到秒回.
*   [TeleMe](https://www.teleme.io/) TeleMe is simple management & analytics software for Telegram communities. TeleMe 是一个方便好用的 Telegram 社群管理和统计 Bot.
*   [Dr.Web](https://t.me/DrWebBot) 用于检测群组内的网页链接和文件，并在包含潜在威胁时发出警告.
*   [daixiahu_bot](https://t.me/daixiahu_bot) 智能合租机器人。合租 求租 智能机器人，方便用户以最快的速度找到合适的车，支持 Netflix, Spotify, Youtube 等
*   [cnLottery123_bot](https://t.me/cnLottery123_bot) 抽奖助手：便好用、公平公正的 Telegram 群组抽奖工具。适用于群里抽奖、抽签抓阄等场景.
*   [tgLotteryBot](https://t.me/tgLotteryBot) 抽奖机器人
*   [sauweenbot](https://t.me/sauweenbot) 一个中文群组管理机器人，内置一些全中文得简单操作
*   [letmebot](https://t.me/letmebot) Teach those pricks how to use a search engine properly.
*   [Doge Bot](https://t.me/jpg_dog_bot) JPG.DOG 的上线 Doge Bot 图床机器人，只需私聊发送图片，即可自动上传图床并返回链接！
*   [areply_bot](https://t.me/areply_bot) 自动解除频道消息在群组的同步置顶，附带群组日常维护常用小功能
*   [WuhanPneumoniaBot](https://t.me/WuhanPneumoniaBot) 武汉新型冠状病毒感染肺炎查询
*   [haoyybot](https://t.me/haoyybot) 歌曲音乐搜索机器人，输入歌曲名或者歌手名，把 TG 变成音乐播放器！
*   [🎵 Music Downloader](https://t.me/MusicDownloaderRobot) Spotify 音乐下载
*   [SangMataInfo_bot](https://t.me/SangMataInfo_bot) 群成员更改名称通知提醒
*   [zlibrary](https://t.me/zlibrarybot) 搜书机器人
*   [Nexus Search](https://t.me/libgen_scihub_bot) 搜书机器人
*   [BookDown](https://t.me/bookdownbot) 搜书机器人
*   [File Converter](https://t.me/newfileconverterbot) 格式转换:azw3 or mobi to epub
*   [Send to Kindle](https://t.me/Send2KindleBot) Send to Kindle Bot
*   [InstantViewBot](https://t.me/CorsaBot) 可以把文章都生成支持 Instant View
*   [ChnInstantViewBot](https://t.me/ChnInstantViewBot) 可以把文章都生成支持 Instant View
*   [WebpageBot](https://t.me/WebpageBot) 强制刷新 Telegram 链接预览
*   [ReactBot](https://t.me/ReactBot) 频道消息添加点赞和评论按钮
*   [ComenBot](https://t.me/ComenBot) 留言 / 评论机器人
*   [CommentsBot](https://t.me/CommentsBot) 留言 / 评论机器人
*   [CommentBot](https://t.me/bakalztbot) 频道消息添加点赞和评论按钮
*   [Like and Comment](https://t.me/LikeComBot) 频道消息添加点赞和评论按钮
*   [Channel Helper](https://t.me/jogle_channel_bot) 频道消息添加点赞和评论按钮
*   [septs_autoclean_bot](https://t.me/septs_autoclean_bot) 频道助手
*   [tgcnjoincaptchabot](https://t.me/tgcnjoincaptchabot) TGCN-CAPTCHA 加群验证
*   [Jqs7ZweiBot](https://t.me/Jqs7ZweiBot) 加群验证
*   [Captchat_Bot](https://t.me/Captchat_Bot) 加群验证
*   [WatchDoorBot](https://t.me/WatchDoorBot) 加群验证
*   [WooMaiBot](https://t.me/WooMaiBot) 加群验证
*   [The Join Captcha Bot](https://t.me/join_captcha_bot) 加群验证
*   [VideoTubeBot](https://t.me/VideoTubeBot) Downloads audio/video from YouTube.
*   [PronunciationBot](https://t.me/PronunciationBot) 可以将 84 种语言文字转换成对应的语音 学习外语发音的利器
*   [Shorten URL](https://t.me/referbot) 提供短网址 ShortenURL 服务，使用的网址为 ume.la
*   [TransferRobot](https://t.me/TransferRobot) 上传文件后提供下载链接，适合做图床和文件分享
*   [SpotifyMusicDownloaderBot](https://t.me/SpotifyMusicDownloaderBot) Spotify Music Downloader
*   [Minesweeper](https://t.me/mine_sweeper_bot) 扫雷游戏
*   [Combot](https://t.me/combot) 统计群消息情况，群成员情况
*   [NodeRSSBot](https://t.me/NodeRSS_bot) A RSSBot written in Node.js https://github.com/fengkx/NodeRSSBot feel free to post issue or pull request
*   [RustRssBot](https://t.me/RustRssBot) 中文 Telegram RSS 机器人
*   [TheFeedReaderBot](https://t.me/TheFeedReaderBot) RSS 机器人
*   [RSSchina_bot](https://t.me/RSSchina_bot) rss 订阅机器人
*   [PdoRSS_bot](https://t.me/PdoRSS_bot) 一个勤勤恳恳的 RSS 订阅器
*   [Warma Bot](https://t.me/warma_bot) 好听的萌妹子声音
*   [get_id_bot](https://t.me/get_id_bot) get your telegram’s chat ID
*   [GroupHub_bot](https://t.me/GroupHub_bot) tg 中文圈优质群组
*   [TWBlackList_bot](https://t.me/TWBlackList_bot) 登爺的名單，辅助管理群成员，帮你 ban 人
*   [CNBlackListRBot](https://t.me/CNBlackListRBot) 辅助管理群成员，帮你 ban 人
*   [GroupButler](https://t.me/GroupButler_bot) This bot can help you in managing your group with rules, anti-flood, description, custom triggers, and much more!
*   [AntiServiceMessageBot](https://t.me/AntiServiceMessageBot) 自动把入群和退群通知删除
*   [Anonymous Telegram Bot](https://t.me/Anonymous_telegram_bot) 群组匿名消息机器人。将机器人加入群组后，私聊机器人，可以通过机器人将文本、视频等匿名发送到群组内.
*   [AntiHyperlinkBot](https://t.me/AntiHyperlinkBot) 自动删除包含有链接的消息
*   [AntiCommandBot](https://t.me/AntiCommandBot) 自动删除 / 命令 的消息
*   [AntiArabicScriptBot](https://t.me/AntiArabicScriptBot) removes all messages which contain arabic script
*   [Giphy GIF Search](https://t.me/gif) GIF 搜索
*   [Wikipedia Search](https://t.me/wiki) Wikipedia 搜索
*   [Markdown Bot](https://t.me/Bold) Markdown 格式编辑消息
*   [JPEGreenBot](https://t.me/JPEGreenBot) 图片劣化
*   [ImageBot](https://t.me/imagebot) This simple bot can fetch images and GIFs upon request.
*   [IMDb](https://t.me/imdb) This bot automatically works in all your chats and groups, no need to add it anywhere. Simply type @imdb in any chat
*   [Classical Music](https://t.me/music) This bot can help you find beautiful classical music.
*   [YouTube Bot](https://t.me/youtube) This bot can help you find and share YouTube videos.
*   [GitHub](https://t.me/githubbot) Get notifications about events in your public GitHub repositories and post comments directly from Telegram.
*   [Shop Bot](https://t.me/shopbot) Try out the new Telegram Payments without actually paying anything.
*   [StickerBot](https://t.me/sticker) This bot will help you find new relevant stickers for your favorite emoji.
*   [Gamee](https://t.me/gamee) The best games on Telegram! Pick a game and challenge your friends
*   [Hot Or Bot](https://t.me/hotorbot) Like others and let others like you.
*   [GetMediaBot](https://getmediabot/) Get any media file from any where…
*   [NoSticker](https://t.me/nosticker_bot) 自动删除群里的 Stickers
*   [SpamMeNotBot](https://t.me/SpamMeNotBot) 保护您的组免受垃圾邮件 / 攻击
*   [socks5_bot](https://t.me/socks5_bot) 免费获得 Socks5 代理
*   [MahoNato_bot](https://t.me/MahoNato_bot) 森近真帆
*   [telegraph](https://t.me/telegraph) 管理 Telegra.ph 文章
*   [mdrobot](https://t.me/mdrobot) Markdown 机器人
*   [referbot](https://t.me/referbot) 提供短网址 Shorten URL 服务，使用的网址为 ume.la
*   [LinkGeneratorBot](https://t.me/LinkGeneratorBot) 短地址服务
*   [QRCodeRoBot](https://t.me/QRCodeRoBot) 二维码识别机器人，通过拍照和上传图片的方式识别
*   [thesafebot](https://t.me/thesafebot) 一个利用 telegram 存储功能实现额外加密的云存储服务
*   [MyTeleCloudBot](https://t.me/MyTeleCloudBot) 另一个云存储服务，没有额外加密，不过功能还行
*   [topdf_bot](https://t.me/topdf_bot) 转换文件为 PDF 格式 ss
*   [Instasave_bot](https://t.me/Instasave_bot) 用来下载 instagram 的 bot
*   [my_ali_bot](https://t.me/my_ali_bot) 用来在 AliExpress 上购物
*   [TrustedSleepBot](https://t.me/TrustedSleepBot) 可信睡眠机器人
*   [ddoc_bot](https://t.me/ddoc_bot) DDOS 攻击器
*   [storebot](https://t.me/storebot) 机器人商店，索引了各种机器人，可以寻找自己感兴趣的
*   [tchannelsbot](https://t.me/tchannelsbot) 索引了很多 Channel, 可以寻找自己感兴趣的 Channel
*   [CostflowCryptoBot](https://t.me/CostflowCryptoBot) Cryptocurrencies
*   [CostflowCurrencyBot](https://t.me/CostflowCurrencyBot) Real world currency rates/convention
*   [stockprice_bot](https://t.me/stockprice_bot) 中文股票机器人，A 股 / 美股 / 港股
*   [LotteryBot](https://t.me/LotteryBot) 一个比特币抽奖的机器人
*   [todobot](https://t.me/todobot) To do list manager
*   [rJailbreakBot](https://t.me/rJailbreakBot) Jailbreak Bot
*   [iqdb_org_bot](https://t.me/iqdb_org_bot) IQDB Bot
*   [ascii2d_bot](https://t.me/ascii2d_bot) Ascii2d Bot
*   [wangjingze_bot](https://t.me/wangjingze_bot) 王境泽 Bot
*   [yaplus_bot](https://t.me/yaplus_bot) Yaplus Bot
*   [kunsu_bot](https://t.me/kunsu_bot) HandsUp Bot
*   [youqianbot](https://t.me/youqianbot) 为所欲为 Bot
*   [redpack_bot](https://t.me/redpack_bot) 红包 Bot
*   [penle_bot](https://t.me/penle_bot) 喷了 Bot
*   [jichou_bot](https://t.me/jichou_bot) 记仇 Bot
*   [bugele_bot](https://t.me/bugele_bot) 不鸽了 Bot
*   [jidubot](https://t.me/jidubot) 嫉妒 Bot
*   [favorite_stickers_bot](https://t.me/favorite_stickers_bot) 贴纸包 Bot
*   [PLGameBot](https://t.me/PLGameBot) 在线游戏的机器人
*   [Cctv365bot](https://t.me/Cctv365bot) 电影搜索
*   [Telegram Bot List](https://github.com/goq/telegram-list/blob/master/bots.md)
*   [Telegram Bot List](https://github.com/eternnoir/pyTelegramBotAPI#bots-using-this-api)
*   [Telegram Bot Store](https://storebot.me/)
*   [Telegram Bots](https://blog.rawstack.co/post/telegram-bots)

#### 参考资料

- [BotoStore](https://botostore.com/) 一个专门收录telegram bot的国外网站，过滤了垃圾邮件和成人内容的bot
- [BotsArchive](https://botsarchive.com/) Telegram机器人档案，不收录成人内容的bottelegram频道：[BotsArchive](https://t.me/BotsArchive)
- [Telegram Bot：@BotsArchiveBot](https://t.me/BotsArchiveBot)
- [Search Telegram Bots](https://botlist.infotelbot.com/) 一个按类型查找电报机器人网站

（排名不分先后）